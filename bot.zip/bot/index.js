const { Client, GatewayIntentBits, Collection, EmbedBuilder, PermissionsBitField, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();
const db = require('./utils/database');
const antiSpam = require('./antiSpam');
const autoMod = require('./autoMod');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildModeration
    ]
});

client.commands = new Collection();
client.afk = new Map();
client.cooldowns = new Collection();

const defaultPrefix = process.env.PREFIX || '!';

function loadCommands(dir) {
    if (!fs.existsSync(dir)) return;
    const files = fs.readdirSync(dir);
    
    for (const file of files) {
        const fullPath = path.join(dir, file);
        const stat = fs.statSync(fullPath);
        
        if (stat.isDirectory()) {
            loadCommands(fullPath);
        } else if (file.endsWith('.js')) {
            try {
                const command = require(fullPath);
                if (command.name) {
                    client.commands.set(command.name, command);
                }
            } catch (error) {
                console.error(`Erro ao carregar ${file}:`, error.message);
            }
        }
    }
}

loadCommands(path.join(__dirname, 'commands'));
console.log(`Comandos carregados: ${client.commands.size}`);

function getPrefix(guildId) {
    if (!guildId) return defaultPrefix;
    const guildConfig = db.getGuildConfig(guildId);
    return guildConfig.prefix || defaultPrefix;
}

async function sendLog(guild, embed) {
    try {
        const guildConfig = db.getGuildConfig(guild.id);
        const logChannelId = guildConfig.modLogChannel || guildConfig.logChannel;
        if (!logChannelId) return;
        const logChannel = guild.channels.cache.get(logChannelId);
        if (logChannel) await logChannel.send({ embeds: [embed] }).catch(() => {});
    } catch (error) {}
}

async function sendLogTo(channelId, guild, embed) {
    if (!channelId) return;
    const channel = guild.channels.cache.get(channelId);
    if (channel) {
        await channel.send({ embeds: [embed] }).catch(() => {});
    }
}

client.sendLog = sendLog;

client.once('ready', () => {
    console.log(`Bot online: ${client.user.tag}`);
    client.user.setActivity('!ajuda | Moderação', { type: 3 });
});

// Boas-vindas
client.on('guildMemberAdd', async (member) => {
    try {
        const config = db.getGuildConfig(member.guild.id);
        if (!config.welcomeChannel) return;
        const channel = member.guild.channels.cache.get(config.welcomeChannel);
        if (!channel) return;

        const msg = config.welcomeMessage
            .replace('{user}', member.toString())
            .replace('{user.tag}', member.user.tag)
            .replace('{server}', member.guild.name)
            .replace('{server.members}', member.guild.memberCount);

        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('👋 Bem-vindo!')
            .setDescription(msg)
            .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
            .setTimestamp();

        await channel.send({ embeds: [embed] }).catch(() => {});
    } catch (error) {}
});

// Despedidas
client.on('guildMemberRemove', async (member) => {
    try {
        const config = db.getGuildConfig(member.guild.id);
        if (!config.goodbyeChannel) return;
        const channel = member.guild.channels.cache.get(config.goodbyeChannel);
        if (!channel) return;

        const msg = config.goodbyeMessage
            .replace('{user}', member.user.tag)
            .replace('{server}', member.guild.name)
            .replace('{server.members}', member.guild.memberCount);

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('👋 Adeus!')
            .setDescription(msg)
            .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
            .setTimestamp();

        await channel.send({ embeds: [embed] }).catch(() => {});
    } catch (error) {}
});

// Log de Ban
client.on('guildBanAdd', async (ban) => {
    try {
        const config = db.getGuildConfig(ban.guild.id);
        const logChannelId = config.modLogChannel || config.logChannel;
        if (!logChannelId) return;

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('🔨 Membro Banido')
            .addFields(
                { name: '👤 Usuário', value: `${ban.user.tag} (${ban.user.id})` },
                { name: '📝 Motivo', value: ban.reason || 'Não especificado' }
            )
            .setTimestamp();

        await sendLogTo(logChannelId, ban.guild, embed);
    } catch (error) {}
});

// Log de Unban
client.on('guildBanRemove', async (ban) => {
    try {
        const config = db.getGuildConfig(ban.guild.id);
        const logChannelId = config.modLogChannel || config.logChannel;
        if (!logChannelId) return;

        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('✅ Membro Desbanido')
            .addFields({ name: '👤 Usuário', value: `${ban.user.tag} (${ban.user.id})` })
            .setTimestamp();

        await sendLogTo(logChannelId, ban.guild, embed);
    } catch (error) {}
});

// Log de Mute/Kick
client.on('guildAuditLogEntryCreate', async (auditLog, guild) => {
    try {
        const config = db.getGuildConfig(guild.id);
        const logChannelId = config.modLogChannel || config.logChannel;
        if (!logChannelId) return;

        if (auditLog.action === 24) {
            const { executor, target, reason } = auditLog;
            if (target && executor) {
                const embed = new EmbedBuilder()
                    .setColor('#FFA500')
                    .setTitle('🔇 Membro Silenciado')
                    .addFields(
                        { name: '👤 Usuário', value: `${target.tag} (${target.id})` },
                        { name: '🛡️ Moderador', value: `${executor.tag}` },
                        { name: '📝 Motivo', value: reason || 'Não especificado' }
                    )
                    .setTimestamp();
                const channel = guild.channels.cache.get(logChannelId);
                if (channel) await channel.send({ embeds: [embed] }).catch(() => {});
            }
        }

        if (auditLog.action === 20) {
            const { executor, target, reason } = auditLog;
            if (target && executor) {
                const embed = new EmbedBuilder()
                    .setColor('#FFA500')
                    .setTitle('👢 Membro Expulso')
                    .addFields(
                        { name: '👤 Usuário', value: `${target.tag} (${target.id})` },
                        { name: '🛡️ Moderador', value: `${executor.tag}` },
                        { name: '📝 Motivo', value: reason || 'Não especificado' }
                    )
                    .setTimestamp();
                const channel = guild.channels.cache.get(logChannelId);
                if (channel) await channel.send({ embeds: [embed] }).catch(() => {});
            }
        }
    } catch (error) {}
});

// Log de mensagens editadas
client.on('messageUpdate', async (oldMessage, newMessage) => {
    if (oldMessage.author?.bot || !oldMessage.guild) return;
    if (oldMessage.content === newMessage.content) return;

    const config = db.getGuildConfig(oldMessage.guild.id);
    const logChannelId = config.messageLogChannel || config.logChannel;
    if (!logChannelId) return;

    const embed = new EmbedBuilder()
        .setColor('#FFA500')
        .setTitle('📝 Mensagem Editada')
        .addFields(
            { name: '👤 Autor', value: oldMessage.author.tag },
            { name: '💬 Canal', value: oldMessage.channel.toString() },
            { name: '📄 Antes', value: oldMessage.content.slice(0, 1024) || '[Sem conteúdo]' },
            { name: '📝 Depois', value: newMessage.content.slice(0, 1024) || '[Sem conteúdo]' }
        )
        .setTimestamp();

    await sendLogTo(logChannelId, oldMessage.guild, embed);
});

// Log de mensagens deletadas
client.on('messageDelete', async (message) => {
    if (message.author?.bot || !message.guild) return;

    const config = db.getGuildConfig(message.guild.id);
    const logChannelId = config.messageLogChannel || config.logChannel;
    if (!logChannelId) return;

    const embed = new EmbedBuilder()
        .setColor('#FF0000')
        .setTitle('🗑️ Mensagem Deletada')
        .addFields(
            { name: '👤 Autor', value: message.author?.tag || 'Desconhecido' },
            { name: '💬 Canal', value: message.channel.toString() },
            { name: '📄 Conteúdo', value: message.content?.slice(0, 1024) || '[Sem conteúdo]' }
        )
        .setTimestamp();

    if (message.attachments.size > 0) {
        embed.addFields({
            name: '📎 Anexos',
            value: message.attachments.map(a => a.url).join('\n').slice(0, 1024)
        });
    }

    await sendLogTo(logChannelId, message.guild, embed);
});

// Log de voz
client.on('voiceStateUpdate', async (oldState, newState) => {
    const guild = newState.guild || oldState.guild;
    const config = db.getGuildConfig(guild.id);
    const logChannelId = config.voiceLogChannel || config.logChannel;
    if (!logChannelId) return;

    const member = newState.member || oldState.member;
    if (!member) return;

    let embed = null;

    if (!oldState.channelId && newState.channelId) {
        embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('🔊 Entrou em Canal de Voz')
            .addFields(
                { name: '👤 Membro', value: member.user.tag },
                { name: '🎙️ Canal', value: newState.channel.name }
            )
            .setTimestamp();
    }

    if (oldState.channelId && !newState.channelId) {
        embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('🔇 Saiu do Canal de Voz')
            .addFields(
                { name: '👤 Membro', value: member.user.tag },
                { name: '🎙️ Canal', value: oldState.channel.name }
            )
            .setTimestamp();
    }

    if (embed) {
        await sendLogTo(logChannelId, guild, embed);
    }
});

// Interações
client.on('interactionCreate', async (interaction) => {
    try {
        // Ticket
        const ticketCommand = client.commands.get('ticket');
        if (ticketCommand && ticketCommand.handleInteraction) {
            if (interaction.customId === 'abrir_ticket' || 
                interaction.customId === 'fechar_ticket' || 
                interaction.customId === 'confirmar_fechar' || 
                interaction.customId === 'cancelar_fechar' || 
                interaction.customId === 'modal_ticket') {
                await ticketCommand.handleInteraction(interaction, client);
                return;
            }
        }

        // Aprovar/Reprovar formulário
        if (interaction.customId?.startsWith('aprovar_') || interaction.customId?.startsWith('reprovar_')) {
            const isAprovar = interaction.customId.startsWith('aprovar_');
            const parts = interaction.customId.split('_');
            const userId = parts[2];

            if (isAprovar) {
                const config = db.getGuildConfig(interaction.guild.id);
                if (config.formApprovalRole) {
                    const member = await interaction.guild.members.fetch(userId).catch(() => {});
                    if (member) await member.roles.add(config.formApprovalRole).catch(() => {});
                }
                await interaction.update({ content: '✅ Aprovado!', components: [], embeds: [] });
            } else {
                await interaction.update({ content: '❌ Reprovado!', components: [], embeds: [] });
            }
            return;
        }

        // Abrir modal do formulário
        if (interaction.customId?.startsWith('form_')) {
            const formNome = interaction.customId.replace('form_', '');
            let forms = {};
            try {
                const formsPath = path.join(__dirname, 'database/forms.json');
                if (fs.existsSync(formsPath)) {
                    forms = JSON.parse(fs.readFileSync(formsPath, 'utf8') || '{}');
                }
            } catch (error) {}

            const form = forms[interaction.guild.id]?.[formNome];
            if (!form) return interaction.reply({ content: '❌ Formulário não encontrado!', ephemeral: true });

            const jaRespondeu = form.respostas?.some(r => r.userId === interaction.user.id);
            if (jaRespondeu) return interaction.reply({ content: '❌ Você já respondeu!', ephemeral: true });

            const modal = new ModalBuilder()
                .setCustomId(`modalform_${formNome}`)
                .setTitle(form.titulo.slice(0, 45));

            const components = [];
            
            const nomeInput = new TextInputBuilder()
                .setCustomId('pergunta_0')
                .setLabel('📛 Seu nome')
                .setValue(interaction.user.username)
                .setStyle(TextInputStyle.Short)
                .setRequired(true);
            components.push(new ActionRowBuilder().addComponents(nomeInput));

            for (let i = 0; i < Math.min(form.perguntas.length, 4); i++) {
                const input = new TextInputBuilder()
                    .setCustomId(`pergunta_${i + 1}`)
                    .setLabel(form.perguntas[i].slice(0, 45))
                    .setPlaceholder('Sua resposta...')
                    .setStyle(TextInputStyle.Paragraph)
                    .setRequired(true)
                    .setMaxLength(1000);
                components.push(new ActionRowBuilder().addComponents(input));
            }

            modal.addComponents(components);
            await interaction.showModal(modal);
            return;
        }

        // Resposta do modal
        if (interaction.customId?.startsWith('modalform_')) {
            const formNome = interaction.customId.replace('modalform_', '');
            let forms = {};
            const formsPath = path.join(__dirname, 'database/forms.json');
            try {
                if (fs.existsSync(formsPath)) {
                    forms = JSON.parse(fs.readFileSync(formsPath, 'utf8') || '{}');
                }
            } catch (error) {}

            const form = forms[interaction.guild.id]?.[formNome];
            if (!form) return interaction.reply({ content: '❌ Erro!', ephemeral: true });

            const respostas = [];
            respostas.push(interaction.fields.getTextInputValue('pergunta_0'));

            for (let i = 0; i < form.perguntas.length; i++) {
                try {
                    const r = interaction.fields.getTextInputValue(`pergunta_${i + 1}`);
                    respostas.push(r);
                } catch { respostas.push('Não respondido'); }
            }

            if (!form.respostas) form.respostas = [];
            form.respostas.push({
                userId: interaction.user.id,
                userTag: interaction.user.tag,
                respostas,
                data: Date.now()
            });

            if (!forms[interaction.guild.id]) forms[interaction.guild.id] = {};
            forms[interaction.guild.id][formNome] = form;
            fs.writeFileSync(formsPath, JSON.stringify(forms, null, 2));

            const config = db.getGuildConfig(interaction.guild.id);
            if (config.formChannel) {
                const channel = interaction.guild.channels.cache.get(config.formChannel);
                if (channel) {
                    const embed = new EmbedBuilder()
                        .setColor('#0099ff')
                        .setTitle(`📋 ${form.titulo}`)
                        .setDescription(`Nova resposta de ${interaction.user}`)
                        .addFields({ name: '👤 Usuário', value: interaction.user.tag }, { name: '📛 Nome', value: respostas[0] });

                    for (let i = 0; i < form.perguntas.length; i++) {
                        embed.addFields({ name: `📝 ${form.perguntas[i]}`, value: respostas[i + 1] || 'Não respondido' });
                    }

                    embed.setTimestamp();

                    const row = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`aprovar_${formNome}_${interaction.user.id}`).setLabel('✅ Aprovar').setStyle(ButtonStyle.Success),
                            new ButtonBuilder().setCustomId(`reprovar_${formNome}_${interaction.user.id}`).setLabel('❌ Reprovar').setStyle(ButtonStyle.Danger)
                        );

                    await channel.send({ embeds: [embed], components: [row] });
                }
            }

            await interaction.reply({ content: '✅ Inscrição enviada! Boa sorte! 🍀', ephemeral: true });
            return;
        }

    } catch (error) {
        console.error('Erro na interação:', error);
        if (interaction.isRepliable()) {
            await interaction.reply({ content: '❌ Ocorreu um erro.', ephemeral: true }).catch(() => {});
        }
    }
});

// Mensagens
client.on('messageCreate', async (message) => {
    if (message.author.bot || !message.guild) return;
    
    const prefix = getPrefix(message.guild.id);
    const config = db.getGuildConfig(message.guild.id);
    
    // AFK
    if (message.mentions.users.size > 0) {
        for (const [userId, afkData] of client.afk) {
            if (message.mentions.users.has(userId)) {
                message.reply({
                    content: `💤 **${afkData.username}** está AFK: ${afkData.reason}\n⏰ Desde: <t:${Math.floor(afkData.timestamp / 1000)}:R>`,
                    allowedMentions: { repliedUser: false }
                }).catch(() => {});
            }
        }
    }
    
    if (client.afk.has(message.author.id)) {
        client.afk.delete(message.author.id);
        message.reply({
            content: '👋 Bem-vindo de volta! AFK removido.',
            allowedMentions: { repliedUser: false }
        }).catch(() => {});
    }
    
    // Sistema de Level
    const levelManager = require('./utils/levelManager');
    const levelUp = levelManager.addXP(message);

    if (levelUp) {
        if (config.levelRewards && config.levelRewards[levelUp.level]) {
            const roleId = config.levelRewards[levelUp.level];
            const role = message.guild.roles.cache.get(roleId);
            if (role && message.member) {
                await message.member.roles.add(role).catch(() => {});
            }
        }
        
        if (config.levelChannel) {
            const levelChannel = message.guild.channels.cache.get(config.levelChannel);
            if (levelChannel) {
                const levelEmbed = new EmbedBuilder()
                    .setColor('#FFD700')
                    .setTitle('🎉 Level Up!')
                    .setDescription(`${message.author} subiu para o nível **${levelUp.level}**!`)
                    .setTimestamp();
                await levelChannel.send({ embeds: [levelEmbed] }).catch(() => {});
            }
        }
    }
    
    // Anti-spam
    if (config.antiSpamEnabled) {
        await antiSpam.checkMessage(message).catch(() => {});
    }
    
    // Anti-link
    if (config.antiLinkEnabled && !message.member?.permissions.has('ModerateMembers')) {
        if (/https?:\/\/[^\s]+/gi.test(message.content)) {
            try {
                await message.delete();
                const warn = await message.channel.send(`${message.author}, ❌ Links não permitidos!`);
                setTimeout(() => warn.delete().catch(() => {}), 5000);
                   } catch (error) {}
            return;
        }
    }
    
    // Auto-Mod
    await autoMod.checkMessage(message).catch(() => {});
    
    if (!message.content.startsWith(prefix)) return;
    
    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();
    
    if (config.commandsDisabled.includes(commandName)) {
        return message.reply('❌ Comando desabilitado!').catch(() => {});
    }
    
    const command = client.commands.get(commandName);
    if (!command) return;
    
    try {
        await command.execute(message, args, client);
    } catch (error) {
        console.error('Erro:', error.message);
        message.reply('❌ Erro ao executar comando!').catch(() => {});
    }
});

client.login(process.env.TOKEN);