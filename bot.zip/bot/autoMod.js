const { PermissionsBitField } = require('discord.js');

class AutoMod {
    constructor() {
        this.inviteRegex = /(?:https?:\/\/)?(?:www\.)?discord(?:\.gg|app\.com\/invite|\.com\/invite)\/[a-zA-Z0-9\-_]+/gi;
        this.capsThreshold = 0.7;
        this.minLengthForCaps = 10;
        this.spamSimilarity = 0.8;
    }

    async checkMessage(message) {
        if (message.author.bot) return;
        if (message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) return;

        let violations = [];

        if (this.hasInvite(message.content)) {
            violations.push({ type: 'invite', action: 'delete' });
        }

        if (this.hasExcessiveCaps(message.content)) {
            violations.push({ type: 'caps', action: 'warn' });
        }

        if (await this.isFlood(message)) {
            violations.push({ type: 'flood', action: 'delete' });
        }

        if (this.hasExcessiveSpoilers(message.content)) {
            violations.push({ type: 'spoiler', action: 'warn' });
        }

        for (const violation of violations) {
            await this.handleViolation(message, violation);
        }

        return violations.length > 0;
    }

    hasInvite(content) {
        return this.inviteRegex.test(content);
    }

    hasExcessiveCaps(content) {
        if (content.length < this.minLengthForCaps) return false;
        const letters = content.replace(/[^a-zA-Z]/g, '');
        if (letters.length === 0) return false;
        const caps = letters.replace(/[^A-Z]/g, '');
        return (caps.length / letters.length) > this.capsThreshold;
    }

    async isFlood(message) {
        const messages = await message.channel.messages.fetch({ limit: 5 });
        const recentMessages = messages.filter(m => 
            m.author.id === message.author.id && 
            Date.now() - m.createdTimestamp < 10000
        );

        if (recentMessages.size < 3) return false;

        const contents = recentMessages.map(m => m.content.toLowerCase());
        const target = message.content.toLowerCase();

        let similarCount = 0;
        for (const content of contents) {
            const similarity = this.calculateSimilarity(target, content);
            if (similarity > this.spamSimilarity) similarCount++;
        }

        return similarCount >= 2;
    }

    hasExcessiveSpoilers(content) {
        const spoilerCount = (content.match(/\|\|/g) || []).length;
        return spoilerCount > 10;
    }

    calculateSimilarity(str1, str2) {
        const longer = str1.length > str2.length ? str1 : str2;
        const shorter = str1.length > str2.length ? str2 : str1;
        if (longer.length === 0) return 1.0;
        const editDistance = (longer.length - this.editDistance(longer, shorter));
        return editDistance / parseFloat(longer.length);
    }

    editDistance(str1, str2) {
        str1 = str1.toLowerCase();
        str2 = str2.toLowerCase();
        const costs = [];
        for (let i = 0; i <= str1.length; i++) {
            let lastValue = i;
            for (let j = 0; j <= str2.length; j++) {
                if (i === 0) costs[j] = j;
                else if (j > 0) {
                    let newValue = costs[j - 1];
                    if (str1.charAt(i - 1) !== str2.charAt(j - 1))
                        newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1;
                    costs[j - 1] = lastValue;
                    lastValue = newValue;
                }
            }
            if (i > 0) costs[str2.length] = lastValue;
        }
        return costs[str2.length];
    }

    async handleViolation(message, violation) {
        try {
            switch (violation.type) {
                case 'invite':
                    await message.delete();
                    const inviteWarn = await message.channel.send(
                        `${message.author}, ❌ Links de convite não são permitidos!`
                    );
                    setTimeout(() => inviteWarn.delete().catch(() => {}), 5000);
                    break;

                case 'caps':
                    const capsWarn = await message.channel.send(
                        `${message.author}, ⚠️ Evite usar muitas letras maiúsculas!`
                    );
                    setTimeout(() => capsWarn.delete().catch(() => {}), 5000);
                    break;

                case 'flood':
                    await message.delete();
                    const floodWarn = await message.channel.send(
                        `${message.author}, ❌ Não repita mensagens!`
                    );
                    setTimeout(() => floodWarn.delete().catch(() => {}), 5000);
                    break;

                case 'spoiler':
                    const spoilerWarn = await message.channel.send(
                        `${message.author}, ⚠️ Muitos spoilers em uma mensagem!`
                    );
                    setTimeout(() => spoilerWarn.delete().catch(() => {}), 5000);
                    break;
            }
        } catch (error) {
            console.error('Erro no AutoMod:', error);
        }
    }
}

module.exports = new AutoMod();