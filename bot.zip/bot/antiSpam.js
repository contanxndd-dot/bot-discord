const { PermissionsBitField } = require('discord.js');

class AntiSpam {
    constructor() {
        this.spamMap = new Map();
        this.violations = new Map();
        this.config = {
            maxMessages: 5,
            timeWindow: 5000,
            muteDuration: 5 * 60 * 1000
        };
    }

    async checkMessage(message) {
        if (message.author.bot) return;
        if (message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) return;

        const userId = message.author.id;
        const now = Date.now();

        if (!this.spamMap.has(userId)) this.spamMap.set(userId, []);
        
        const timestamps = this.spamMap.get(userId);
        timestamps.push(now);
        const recent = timestamps.filter(t => now - t < this.config.timeWindow);
        this.spamMap.set(userId, recent);

        if (recent.length > this.config.maxMessages) {
            await this.punish(message);
            return true;
        }
        return false;
    }

    async punish(message) {
        const userId = message.author.id;
        const violations = (this.violations.get(userId) || 0) + 1;
        this.violations.set(userId, violations);
        
        const duration = Math.min(violations * 5 * 60 * 1000, 60 * 60 * 1000);

        try {
            const messages = await message.channel.messages.fetch({ limit: 10 });
            const userMessages = messages.filter(m => m.author.id === userId);
            if (userMessages.size > 0) await message.channel.bulkDelete(userMessages).catch(() => {});

            await message.member.timeout(duration, 'Spam');
            const minutes = Math.floor(duration / 60000);
            
            const msg = await message.channel.send(
                `🚫 ${message.author} foi silenciado por ${minutes} minuto(s) por spam!`
            );
            setTimeout(() => msg.delete().catch(() => {}), 5000);
        } catch (error) {
            console.error('Erro anti-spam:', error);
        }
    }
}

module.exports = new AntiSpam();