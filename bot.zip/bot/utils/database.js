const fs = require('fs');
const path = require('path');

class Database {
    constructor() {
        this.dbPath = path.join(__dirname, '../database');
        if (!fs.existsSync(this.dbPath)) {
            fs.mkdirSync(this.dbPath, { recursive: true });
        }
    }

    read(fileName) {
        const filePath = path.join(this.dbPath, fileName);
        try {
            if (!fs.existsSync(filePath)) {
                this.write(fileName, {});
                return {};
            }
            const data = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(data || '{}');
        } catch (error) {
            console.error(`Erro ao ler ${fileName}:`, error);
            return {};
        }
    }

    write(fileName, data) {
        const filePath = path.join(this.dbPath, fileName);
        try {
            fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
            return true;
        } catch (error) {
            console.error(`Erro ao escrever ${fileName}:`, error);
            return false;
        }
    }

    getGuildConfig(guildId) {
        const config = this.read('config.json');
        return config[guildId] || this.getDefaultConfig();
    }

    setGuildConfig(guildId, key, value) {
        const config = this.read('config.json');
        if (!config[guildId]) config[guildId] = this.getDefaultConfig();
        config[guildId][key] = value;
        return this.write('config.json', config);
    }

    updateGuildConfig(guildId, updates) {
        const config = this.read('config.json');
        if (!config[guildId]) config[guildId] = this.getDefaultConfig();
        config[guildId] = { ...config[guildId], ...updates, updatedAt: Date.now() };
        return this.write('config.json', config);
    }

    resetGuildConfig(guildId) {
        const config = this.read('config.json');
        config[guildId] = this.getDefaultConfig();
        return this.write('config.json', config);
    }

    getDefaultConfig() {
        return {
            prefix: '!',
            logChannel: null,
            modLogChannel: null,
            messageLogChannel: null,
            voiceLogChannel: null,
            memberLogChannel: null,
            roleLogChannel: null,
            welcomeChannel: null,
            goodbyeChannel: null,
            announceChannel: null,
            levelChannel: null,
            levelRewards: {},
            formChannel: null,
            formApprovalRole: null,
            ticketTitle: null,
            ticketDescription: null,
            ticketButton: null,
            welcomeMessage: 'Bem-vindo(a) {user} ao {server}!',
            goodbyeMessage: '{user} saiu do servidor',
            antiSpamEnabled: true,
            antiLinkEnabled: false,
            antiRaidEnabled: false,
            emergencyMode: false,
            lockdownMode: false,
            whitelist: [],
            blacklist: [],
            maxWarnsBeforeMute: 3,
            maxWarnsBeforeKick: 5,
            maxWarnsBeforeBan: 7,
            commandsDisabled: [],
            ticketPanelChannel: null,
            ticketPanelMessage: null,
            ticketCategory: null,
            ticketSupportRole: null,
            antiRaidConfig: {
                maxJoins: 10,
                joinTimeWindow: 10000,
                maxBans: 5,
                banTimeWindow: 10000,
                maxChannels: 5,
                channelTimeWindow: 10000
            }
        };
    }
}

module.exports = new Database();