const fs = require('fs');
const path = require('path');

const xpFile = path.join(__dirname, '../database/xp.json');

class LevelManager {
    constructor() {
        this.xpCooldown = new Set();
    }

    getData() {
        try {
            if (!fs.existsSync(xpFile)) {
                fs.writeFileSync(xpFile, '{}');
                return {};
            }
            return JSON.parse(fs.readFileSync(xpFile, 'utf8') || '{}');
        } catch {
            return {};
        }
    }

    saveData(data) {
        fs.writeFileSync(xpFile, JSON.stringify(data, null, 2));
    }

    getLevel(xp) {
        return Math.floor(0.1 * Math.sqrt(xp));
    }

    getXpForLevel(level) {
        return Math.pow(level / 0.1, 2);
    }

    addXP(message) {
        if (message.author.bot) return null;
        if (this.xpCooldown.has(message.author.id)) return null;

        this.xpCooldown.add(message.author.id);
        setTimeout(() => this.xpCooldown.delete(message.author.id), 60000);

        const data = this.getData();
        if (!data[message.guild.id]) data[message.guild.id] = {};
        if (!data[message.guild.id][message.author.id]) {
            data[message.guild.id][message.author.id] = {
                xp: 0,
                level: 0,
                messages: 0
            };
        }

        const userData = data[message.guild.id][message.author.id];
        const xpGain = Math.floor(Math.random() * 30) + 20;
        
        userData.xp += xpGain;
        userData.messages++;
        
        const oldLevel = userData.level;
        const newLevel = this.getLevel(userData.xp);
        
        let levelUp = false;
        if (newLevel > oldLevel) {
            userData.level = newLevel;
            levelUp = true;
        }

        this.saveData(data);

        if (levelUp) {
            return {
                user: message.author,
                level: newLevel,
                xp: userData.xp
            };
        }
        return null;
    }

    getRank(guildId, userId) {
        const data = this.getData();
        if (!data[guildId]) return null;
        
        const members = Object.entries(data[guildId])
            .sort((a, b) => b[1].xp - a[1].xp);
        
        const rank = members.findIndex(([id]) => id === userId) + 1;
        const userData = data[guildId][userId];
        
        if (!userData) return null;
        
        return {
            rank,
            level: userData.level,
            xp: userData.xp,
            messages: userData.messages || 0,
            nextLevelXp: this.getXpForLevel(userData.level + 1)
        };
    }

    getTop(guildId, limit = 10) {
        const data = this.getData();
        if (!data[guildId]) return [];
        
        return Object.entries(data[guildId])
            .sort((a, b) => b[1].xp - a[1].xp)
            .slice(0, limit)
            .map(([userId, userData], index) => ({
                rank: index + 1,
                userId,
                level: userData.level,
                xp: userData.xp,
                messages: userData.messages || 0
            }));
    }
}

module.exports = new LevelManager();