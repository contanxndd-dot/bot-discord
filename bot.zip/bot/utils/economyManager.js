const fs = require('fs');
const path = require('path');

const moneyFile = path.join(__dirname, '../database/money.json');

class EconomyManager {
    constructor() {
        this.cooldowns = new Map();
    }

    getData() {
        try {
            if (!fs.existsSync(moneyFile)) {
                fs.writeFileSync(moneyFile, '{}');
                return {};
            }
            return JSON.parse(fs.readFileSync(moneyFile, 'utf8') || '{}');
        } catch {
            return {};
        }
    }

    saveData(data) {
        fs.writeFileSync(moneyFile, JSON.stringify(data, null, 2));
    }

    getBalance(guildId, userId) {
        const data = this.getData();
        if (!data[guildId]) data[guildId] = {};
        if (!data[guildId][userId]) data[guildId][userId] = { balance: 0, lastDaily: 0 };
        return data[guildId][userId].balance || 0;
    }

    setBalance(guildId, userId, amount) {
        const data = this.getData();
        if (!data[guildId]) data[guildId] = {};
        if (!data[guildId][userId]) data[guildId][userId] = { balance: 0, lastDaily: 0 };
        data[guildId][userId].balance = amount;
        this.saveData(data);
    }

    addMoney(guildId, userId, amount) {
        const current = this.getBalance(guildId, userId);
        this.setBalance(guildId, userId, current + amount);
    }

    removeMoney(guildId, userId, amount) {
        const current = this.getBalance(guildId, userId);
        if (current < amount) return false;
        this.setBalance(guildId, userId, current - amount);
        return true;
    }

    canDaily(guildId, userId) {
        const data = this.getData();
        if (!data[guildId]?.[userId]) return true;
        const lastDaily = data[guildId][userId].lastDaily || 0;
        const now = Date.now();
        const cooldown = 24 * 60 * 60 * 1000; // 24 horas
        return (now - lastDaily) >= cooldown;
    }

    setDaily(guildId, userId) {
        const data = this.getData();
        if (!data[guildId]) data[guildId] = {};
        if (!data[guildId][userId]) data[guildId][userId] = { balance: 0, lastDaily: 0 };
        data[guildId][userId].lastDaily = Date.now();
        
        const bonus = Math.floor(Math.random() * 500) + 200;
        data[guildId][userId].balance += bonus;
        this.saveData(data);
        return bonus;
    }

    getCooldown(guildId, userId) {
        const data = this.getData();
        if (!data[guildId]?.[userId]) return 0;
        const lastDaily = data[guildId][userId].lastDaily || 0;
        const now = Date.now();
        const cooldown = 24 * 60 * 60 * 1000;
        const remaining = cooldown - (now - lastDaily);
        return remaining > 0 ? remaining : 0;
    }
}

module.exports = new EconomyManager();