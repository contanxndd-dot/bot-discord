const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

class GiveawayManager {
    constructor() {
        this.giveaways = new Map();
    }

    async create(message, args, client) {
        const timeStr = args[0];
        const winners = parseInt(args[1]);
        const prize = args.slice(2).join(' ');

        if (!timeStr || !winners || !prize) {
            message.channel.send('❌ Use: `!giveaway iniciar <tempo> <ganhadores> <prêmio>`\nEx: `!giveaway iniciar 10m 1 Nitro`');
            return;
        }

        const time = this.parseTime(timeStr);
        if (!time) {
            message.channel.send('❌ Tempo inválido! Use: `s` (segundos), `m` (minutos), `h` (horas), `d` (dias)');
            return;
        }

        if (winners < 1 || winners > 10) {
            message.channel.send('❌ Número de ganhadores: 1-10');
            return;
        }

        const endTime = Date.now() + time;
        const endTimestamp = Math.floor(endTime / 1000);

        const embed = new EmbedBuilder()
            .setColor('#FF00FF')
            .setTitle('🎉 SORTEIO')
            .setDescription([
                `🎁 **Prêmio:** ${prize}`,
                `👑 **Ganhadores:** ${winners}`,
                `⏰ **Termina:** <t:${endTimestamp}:R>`,
                '',
                'Clique em 🎉 para participar!'
            ].join('\n'))
            .setFooter({ text: `Criado por ${message.author.tag}` })
            .setTimestamp(endTime);

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('enter_giveaway')
                    .setLabel('Participar')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('🎉')
            );

        const msg = await message.channel.send({ embeds: [embed], components: [row] });
        await msg.react('🎉');

        const giveawayData = {
            messageId: msg.id,
            channelId: message.channel.id,
            guildId: message.guild.id,
            prize,
            winners,
            endTime,
            creator: message.author.id,
            participants: new Set()
        };

        this.giveaways.set(msg.id, giveawayData);
        setTimeout(() => this.end(msg.id, client), time);
    }

    async end(messageId, client) {
        const giveaway = this.giveaways.get(messageId);
        if (!giveaway) return;

        const channel = client.channels.cache.get(giveaway.channelId);
        if (!channel) return;

        const message = await channel.messages.fetch(messageId).catch(() => {});
        if (!message) return;

        const reaction = message.reactions.cache.get('🎉');
        if (!reaction) return;

        const users = await reaction.users.fetch();
        const participants = users.filter(u => !u.bot);

        let winners = [];
        if (participants.size > 0) {
            const participantArray = Array.from(participants.values());
            const winnerCount = Math.min(giveaway.winners, participantArray.length);
            
            for (let i = 0; i < winnerCount; i++) {
                const index = Math.floor(Math.random() * participantArray.length);
                winners.push(participantArray[index]);
                participantArray.splice(index, 1);
            }
        }

        const embed = EmbedBuilder.from(message.embeds[0])
            .setColor('#FF0000')
            .setTitle('🎉 SORTEIO ENCERRADO')
            .setDescription([
                `🎁 **Prêmio:** ${giveaway.prize}`,
                '',
                winners.length > 0 
                    ? `🏆 **Ganhador(es):** ${winners.map(w => w.toString()).join(', ')}`
                    : '❌ Ninguém participou do sorteio!',
                '',
                `📊 **Total de participantes:** ${participants.size}`
            ].join('\n'))
            .setTimestamp();

        await message.edit({ embeds: [embed], components: [] });

        if (winners.length > 0) {
            await channel.send(
                `🎉 Parabéns ${winners.map(w => w.toString()).join(', ')}! ` +
                `Você(s) ganhou(ram): **${giveaway.prize}**!`
            );
        }

        this.giveaways.delete(messageId);
    }

    parseTime(str) {
        const match = str.match(/^(\d+)([smhd])$/);
        if (!match) return null;

        const value = parseInt(match[1]);
        const unit = match[2];

        switch (unit) {
            case 's': return value * 1000;
            case 'm': return value * 60 * 1000;
            case 'h': return value * 60 * 60 * 1000;
            case 'd': return value * 24 * 60 * 60 * 1000;
            default: return null;
        }
    }
}

module.exports = new GiveawayManager();