const { EmbedBuilder } = require('discord.js');

class ProtecaoManager {
    constructor() {
        this.raidDetector = new Map();
        this.config = {
            massJoin: {
                maxJoins: 10,
                timeWindow: 10000,
                action: 'lockdown'
            },
            massBan: {
                maxBans: 5,
                timeWindow: 10000,
                action: 'lockdown'
            },
            massChannel: {
                maxChannels: 5,
                timeWindow: 10000,
                action: 'lockdown'
            }
        };
    }

    async detectMassJoin(guild, client) {
        const key = `${guild.id}_joins`;
        const now = Date.now();

        if (!this.raidDetector.has(key)) this.raidDetector.set(key, []);

        const joins = this.raidDetector.get(key);
        joins.push(now);
        const recent = joins.filter(t => now - t < this.config.massJoin.timeWindow);
        this.raidDetector.set(key, recent);

        if (recent.length >= this.config.massJoin.maxJoins) {
            await this.triggerRaidProtection(guild, client, 'entrada em massa');
            return true;
        }
        return false;
    }

    async detectMassBan(guild, client) {
        const key = `${guild.id}_bans`;
        const now = Date.now();

        if (!this.raidDetector.has(key)) this.raidDetector.set(key, []);

        const bans = this.raidDetector.get(key);
        bans.push(now);
        const recent = bans.filter(t => now - t < this.config.massBan.timeWindow);
        this.raidDetector.set(key, recent);

        if (recent.length >= this.config.massBan.maxBans) {
            await this.triggerRaidProtection(guild, client, 'bans em massa');
            return true;
        }
        return false;
    }

    async detectMassChannel(guild, client) {
        const key = `${guild.id}_channels`;
        const now = Date.now();

        if (!this.raidDetector.has(key)) this.raidDetector.set(key, []);

        const channels = this.raidDetector.get(key);
        channels.push(now);
        const recent = channels.filter(t => now - t < this.config.massChannel.timeWindow);
        this.raidDetector.set(key, recent);

        if (recent.length >= this.config.massChannel.maxChannels) {
            await this.triggerRaidProtection(guild, client, 'criação de canais em massa');
            return true;
        }
        return false;
    }

    async triggerRaidProtection(guild, client, motivo) {
        const db = require('./database');
        const config = db.getGuildConfig(guild.id);

        if (!config.antiRaidEnabled) return;

        console.log(`🚨 RAID DETECTADA em ${guild.name}: ${motivo}`);

        const channels = guild.channels.cache.filter(c => c.isTextBased());
        
        for (const [id, channel] of channels) {
            try {
                await channel.permissionOverwrites.edit(guild.roles.everyone, {
                    SendMessages: false,
                    CreatePublicThreads: false,
                    CreatePrivateThreads: false,
                    SendMessagesInThreads: false
                });
            } catch (error) {}
        }

        try {
            await guild.setVerificationLevel(3);
        } catch (error) {}

        const logChannelId = config.logChannel;
        if (logChannelId) {
            const logChannel = guild.channels.cache.get(logChannelId);
            if (logChannel) {
                const embed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('🚨 RAID DETECTADA')
                    .setDescription([
                        `**Servidor:** ${guild.name}`,
                        `**Motivo:** ${motivo}`,
                        `**Horário:** <t:${Math.floor(Date.now() / 1000)}:F>`,
                        '',
                        '**Ações automáticas:**',
                        '🔒 Todos os canais trancados',
                        '🛡️ Verificação: Nível Alto',
                        '',
                        '⚠️ **Use `!lockall` para manter trancado**',
                        '🔓 **Use `!unlockall` para destrancar**'
                    ].join('\n'))
                    .setTimestamp();

                await logChannel.send({ 
                    content: '@everyone 🚨 ALERTA DE RAID!',
                    embeds: [embed] 
                });
            }
        }

        db.setGuildConfig(guild.id, 'emergencyMode', true);
    }

    isWhitelisted(guildId, userId) {
        const db = require('./database');
        const config = db.getGuildConfig(guildId);
        const whitelist = config.whitelist || [];
        return whitelist.includes(userId);
    }

    isBlacklisted(guildId, userId) {
        const db = require('./database');
        const config = db.getGuildConfig(guildId);
        const blacklist = config.blacklist || [];
        return blacklist.includes(userId);
    }

    addWhitelist(guildId, userId) {
        const db = require('./database');
        const config = db.getGuildConfig(guildId);
        if (!config.whitelist) config.whitelist = [];
        
        if (!config.whitelist.includes(userId)) {
            config.whitelist.push(userId);
            db.updateGuildConfig(guildId, config);
            return true;
        }
        return false;
    }

    removeWhitelist(guildId, userId) {
        const db = require('./database');
        const config = db.getGuildConfig(guildId);
        if (!config.whitelist) config.whitelist = [];
        
        config.whitelist = config.whitelist.filter(id => id !== userId);
        db.updateGuildConfig(guildId, config);
        return true;
    }

    addBlacklist(guildId, userId) {
        const db = require('./database');
        const config = db.getGuildConfig(guildId);
        if (!config.blacklist) config.blacklist = [];
        
        if (!config.blacklist.includes(userId)) {
            config.blacklist.push(userId);
            db.updateGuildConfig(guildId, config);
            return true;
        }
        return false;
    }

    removeBlacklist(guildId, userId) {
        const db = require('./database');
        const config = db.getGuildConfig(guildId);
        if (!config.blacklist) config.blacklist = [];
        
        config.blacklist = config.blacklist.filter(id => id !== userId);
        db.updateGuildConfig(guildId, config);
        return true;
    }
}

module.exports = new ProtecaoManager();