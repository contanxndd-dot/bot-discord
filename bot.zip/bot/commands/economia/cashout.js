const economy = require('../../utils/economyManager');

const mineGames = new Map();
// Compartilhar o mesmo Map do mines.js
module.exports = {
    name: 'cashout',
    description: 'Retira seus ganhos do Mines',
    async execute(message, args, client) {
        const game = require('./mines').mineGames?.get(message.author.id);
        
        if (!game) {
            return message.reply('❌ Você não tem um jogo de Mines ativo!');
        }

        const ganhos = game.bet * game.multiplier;
        economy.addMoney(game.guildId, message.author.id, ganhos);

        // Revelar tabuleiro
        game.board.forEach(cell => cell.revealed = true);
        
        const embed = new (require('discord.js').EmbedBuilder)()
            .setColor('#00FF00')
            .setTitle('💰 Cashout!')
            .setDescription(`${message.author} retirou **${ganhos} sonhos**! (x${game.multiplier})`)
            .setTimestamp();

        message.channel.send({ embeds: [embed] });

        // Limpar jogo
        const mineGamesMap = require('./mines').mineGames;
        if (mineGamesMap) mineGamesMap.delete(message.author.id);
    }
};