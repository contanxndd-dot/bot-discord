const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const economy = require('../../utils/economyManager');

const mineGames = new Map();

module.exports = {
    name: 'mines',
    description: 'Jogo de Minas (Campo Minado)',
    async execute(message, args, client) {
        const bet = parseInt(args[0]);

        if (!bet || bet < 10) {
            return message.reply('❌ Use: `!mines <aposta>`\nAposta mínima: 10 sonhos');
        }

        const balance = economy.getBalance(message.guild.id, message.author.id);
        if (balance < bet) {
            return message.reply(`❌ Saldo insuficiente!\nSaldo: **${balance}** sonhos`);
        }

        if (mineGames.has(message.author.id)) {
            return message.reply('❌ Você já tem um jogo em andamento!');
        }

        economy.removeMoney(message.guild.id, message.author.id, bet);

        // Criar tabuleiro 5x5 com 3 bombas
        const board = [];
        const bombs = [];
        while (bombs.length < 3) {
            const pos = Math.floor(Math.random() * 25);
            if (!bombs.includes(pos)) bombs.push(pos);
        }

        for (let i = 0; i < 25; i++) {
            board.push({
                revealed: false,
                bomb: bombs.includes(i),
                multiplier: Math.floor((i + 1) * 0.5) + 1
            });
        }

        const game = {
            bet,
            board,
            guildId: message.guild.id,
            revealed: 0,
            multiplier: 1
        };

        const msg = await message.channel.send({
            embeds: [createMinesEmbed(game)],
            components: createMinesButtons(game)
        });

        mineGames.set(message.author.id, { ...game, messageId: msg.id });

        setTimeout(() => {
            if (mineGames.has(message.author.id)) {
                endMineGame(message.author.id, client, 'timeout');
            }
        }, 120000);
    }
};

function createMinesEmbed(game) {
    const display = game.board.map((cell, i) => {
        if (cell.revealed) {
            return cell.bomb ? '💣' : '💎';
        }
        return '⬜';
    });

    const grid = [];
    for (let i = 0; i < 5; i++) {
        grid.push(display.slice(i * 5, (i + 1) * 5).join(''));
    }

    const embed = new EmbedBuilder()
        .setColor('#9b59b6')
        .setTitle('💣 Minas')
        .setDescription(`**Aposta:** ${game.bet} sonhos\n**Multiplicador:** x${game.multiplier}\n\n${grid.join('\n')}`)
        .setFooter({ text: 'Escolha um botão para revelar!' });

    return embed;
}

function createMinesButtons(game) {
    const rows = [];
    for (let row = 0; row < 5; row++) {
        const rowButtons = new ActionRowBuilder();
        for (let col = 0; col < 5; col++) {
            const index = row * 5 + col;
            rowButtons.addComponents(
                new ButtonBuilder()
                    .setCustomId(`mine_${index}`)
                    .setLabel(game.board[index].revealed ? (game.board[index].bomb ? '💣' : '💎') : '?')
                    .setStyle(game.board[index].revealed ? 
                        (game.board[index].bomb ? ButtonStyle.Danger : ButtonStyle.Success) : 
                        ButtonStyle.Primary)
                    .setDisabled(game.board[index].revealed)
            );
        }
        rows.push(rowButtons);
    }
    return rows;
}

function endMineGame(userId, client, reason) {
    const game = mineGames.get(userId);
    if (!game) return;
    mineGames.delete(userId);

    // Revelar todas as bombas
    game.board.forEach(cell => {
        if (cell.bomb) cell.revealed = true;
    });

    const embed = createMinesEmbed(game);
    embed.setTitle(reason === 'bomb' ? '💣 BOOM! Você perdeu!' : '⏰ Tempo esgotado!');

    client.channels.cache.find(c => c.messages?.cache.has(game.messageId))?.messages.fetch(game.messageId)
        .then(msg => msg.edit({ embeds: [embed], components: [] }))
        .catch(() => {});
}

module.exports.handleInteraction = async function(interaction, client) {
    if (!interaction.customId?.startsWith('mine_')) return;

    const game = mineGames.get(interaction.user.id);
    if (!game) return interaction.reply({ content: '❌ Jogo não encontrado!', ephemeral: true });

    const index = parseInt(interaction.customId.replace('mine_', ''));
    
    if (game.board[index].revealed) {
        return interaction.deferUpdate();
    }

    game.board[index].revealed = true;

    if (game.board[index].bomb) {
        // Perdeu
        endMineGame(interaction.user.id, client, 'bomb');
        await interaction.update({ embeds: [createMinesEmbed(game)], components: [] });
        return;
    }

    // Ganhou pontos
    game.revealed++;
    game.multiplier = Math.floor((game.revealed + 1) * 1.5);

    const embed = createMinesEmbed(game);
    embed.setFooter({ text: `Multiplicador atual: x${game.multiplier} | Use !mines cashout para retirar` });

    await interaction.update({ embeds: [embed], components: createMinesButtons(game) });
};