const { EmbedBuilder } = require('discord.js');
const economy = require('../../utils/economyManager');

module.exports = {
    name: 'pay',
    description: 'Transfere sonhos para alguém',
    async execute(message, args, client) {
        const user = message.mentions.users.first();
        const amount = parseInt(args[1]);

        if (!user || !amount || amount < 1) {
            return message.reply('❌ Use: `!pay @user <quantidade>`');
        }

        if (user.id === message.author.id) {
            return message.reply('❌ Você não pode pagar a si mesmo!');
        }

        const balance = economy.getBalance(message.guild.id, message.author.id);
        if (balance < amount) {
            return message.reply(`❌ Você não tem sonhos suficientes!\nSeu saldo: **${balance}** sonhos`);
        }

        economy.removeMoney(message.guild.id, message.author.id, amount);
        economy.addMoney(message.guild.id, user.id, amount);

        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('💸 Transferência')
            .setDescription(`${message.author} pagou **${amount} sonhos** para ${user}`)
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    }
};