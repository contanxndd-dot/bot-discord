const { EmbedBuilder } = require('discord.js');
const economy = require('../../utils/economyManager');

module.exports = {
    name: 'saldo',
    description: 'Mostra seu saldo de sonhos',
    async execute(message, args, client) {
        const user = message.mentions.users.first() || message.author;
        const balance = economy.getBalance(message.guild.id, user.id);

        const embed = new EmbedBuilder()
            .setColor('#FFD700')
            .setTitle('💰 Saldo')
            .setDescription(`${user} tem **${balance} sonhos** 💎`)
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    }
};