const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const economy = require('../../utils/economyManager');

const games = new Map();

module.exports = {
    name: 'blackjack',
    description: 'Jogo de 21 (Blackjack)',
    async execute(message, args, client) {
        const bet = parseInt(args[0]);

        if (!bet || bet < 10) {
            return message.reply('❌ Use: `!blackjack <aposta>`\nAposta mínima: 10 sonhos');
        }

        const balance = economy.getBalance(message.guild.id, message.author.id);
        if (balance < bet) {
            return message.reply(`❌ Você não tem sonhos suficientes!\nSaldo: **${balance}** sonhos`);
        }

        if (games.has(message.author.id)) {
            return message.reply('❌ Você já tem um jogo em andamento!');
        }

        economy.removeMoney(message.guild.id, message.author.id, bet);

        // Criar jogo
        const deck = createDeck();
        const playerCards = [drawCard(deck), drawCard(deck)];
        const dealerCards = [drawCard(deck), drawCard(deck)];

        const game = {
            bet,
            deck,
            playerCards,
            dealerCards,
            messageId: null,
            guildId: message.guild.id
        };

        const embed = createEmbed(game, false);
        const row = createButtons();

        const msg = await message.channel.send({ embeds: [embed], components: [row] });
        game.messageId = msg.id;
        games.set(message.author.id, game);

        // Timer de 60 segundos
        setTimeout(() => {
            if (games.has(message.author.id)) {
                endGame(message.author.id, client, 'timeout');
            }
        }, 60000);
    }
};

function createDeck() {
    const suits = ['♠', '♥', '♦', '♣'];
    const values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
    const deck = [];
    for (const suit of suits) {
        for (const value of values) {
            deck.push({ suit, value });
        }
    }
    // Embaralhar
    for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    return deck;
}

function drawCard(deck) {
    return deck.pop();
}

function cardValue(card) {
    if (['J', 'Q', 'K'].includes(card.value)) return 10;
    if (card.value === 'A') return 11;
    return parseInt(card.value);
}

function handValue(cards) {
    let value = cards.reduce((sum, card) => sum + cardValue(card), 0);
    let aces = cards.filter(c => c.value === 'A').length;
    
    while (value > 21 && aces > 0) {
        value -= 10;
        aces--;
    }
    return value;
}

function cardsString(cards, hideSecond = false) {
    if (hideSecond) {
        return `${cards[0].value}${cards[0].suit} | ?`;
    }
    return cards.map(c => `${c.value}${c.suit}`).join(' | ');
}

function createEmbed(game, showDealer = false) {
    const playerValue = handValue(game.playerCards);
    const dealerValue = showDealer ? handValue(game.dealerCards) : '?';

    let color = '#0099ff';
    let status = '🃏 Sua vez! Clique em **Pedir** ou **Parar**';

    if (showDealer) {
        if (playerValue > 21) {
            color = '#FF0000';
            status = '💀 Você estourou!';
        } else if (dealerValue > 21) {
            color = '#00FF00';
            status = '🎉 Dealer estourou! Você ganhou!';
        } else if (playerValue > dealerValue) {
            color = '#00FF00';
            status = '🎉 Você ganhou!';
        } else if (playerValue < dealerValue) {
            color = '#FF0000';
            status = '😢 Você perdeu!';
        } else {
            color = '#FFA500';
            status = '🤝 Empate!';
        }
    }

    if (playerValue === 21 && game.playerCards.length === 2) {
        color = '#FFD700';
        status = '🌟 BLACKJACK!';
    }

    const embed = new EmbedBuilder()
        .setColor(color)
        .setTitle('🃏 Blackjack')
        .setDescription(`**Aposta:** ${game.bet} sonhos`)
        .addFields(
            { name: '🏦 Dealer', value: `${cardsString(game.dealerCards, !showDealer)}\nValor: ${showDealer ? dealerValue : '?'}` },
            { name: '👤 Você', value: `${cardsString(game.playerCards)}\nValor: ${playerValue}` },
            { name: '📊 Status', value: status }
        );

    return embed;
}

function createButtons(disabled = false) {
    return new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('bj_hit')
                .setLabel('Pedir')
                .setStyle(ButtonStyle.Primary)
                .setEmoji('🃏')
                .setDisabled(disabled),
            new ButtonBuilder()
                .setCustomId('bj_stand')
                .setLabel('Parar')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('✋')
                .setDisabled(disabled)
        );
}

async function endGame(userId, client, reason) {
    const game = games.get(userId);
    if (!game) return;

    games.delete(userId);
    
    try {
        const channel = client.channels.cache.find(c => c.messages?.cache.has(game.messageId));
        if (!channel) return;

        const msg = await channel.messages.fetch(game.messageId).catch(() => {});
        if (!msg) return;

        const playerValue = handValue(game.playerCards);
        let dealerValue = handValue(game.dealerCards);

        // Dealer compra se tiver menos de 17
        if (reason !== 'timeout' && reason !== 'stand') {
            // timeout = perde automaticamente
        }

        if (reason === 'stand' || reason === 'bust') {
            while (dealerValue < 17) {
                game.dealerCards.push(drawCard(game.deck));
                dealerValue = handValue(game.dealerCards);
            }
        }

        const embed = createEmbed(game, true);
        
        // Resultado
        let result = '';
        if (playerValue > 21) {
            result = 'perdeu';
        } else if (dealerValue > 21) {
            result = 'ganhou';
            economy.addMoney(game.guildId, userId, game.bet * 2);
        } else if (playerValue > dealerValue) {
            result = 'ganhou';
            economy.addMoney(game.guildId, userId, game.bet * 2);
        } else if (playerValue < dealerValue) {
            result = 'perdeu';
        } else {
            result = 'empatou';
            economy.addMoney(game.guildId, userId, game.bet);
        }

        // Blackjack paga 3:2
        if (playerValue === 21 && game.playerCards.length === 2 && dealerValue !== 21) {
            result = 'blackjack';
            economy.addMoney(game.guildId, userId, Math.floor(game.bet * 2.5));
        }

        const resultEmbed = new EmbedBuilder()
            .setColor(result === 'ganhou' || result === 'blackjack' ? '#00FF00' : '#FF0000')
            .setDescription(`Resultado: ${result === 'ganhou' ? '🎉 Ganhou ' + game.bet * 2 : result === 'blackjack' ? '🌟 BLACKJACK! ' + Math.floor(game.bet * 2.5) : result === 'empatou' ? '🤝 Empate! ' + game.bet : '😢 Perdeu ' + game.bet} sonhos`);

        await msg.edit({ embeds: [embed, resultEmbed], components: [] });
    } catch (error) {
        console.error('Erro blackjack:', error);
    }
}

// Eventos dos botões (adicione no interactionCreate do index.js)
module.exports.handleInteraction = async function(interaction, client) {
    if (interaction.customId === 'bj_hit') {
        const game = games.get(interaction.user.id);
        if (!game) return interaction.reply({ content: '❌ Jogo não encontrado!', ephemeral: true });

        game.playerCards.push(drawCard(game.deck));
        const value = handValue(game.playerCards);

        if (value >= 21) {
            await endGame(interaction.user.id, client, 'bust');
            await interaction.deferUpdate();
        } else {
            const embed = createEmbed(game, false);
            await interaction.update({ embeds: [embed], components: [createButtons()] });
        }
    }

    if (interaction.customId === 'bj_stand') {
        const game = games.get(interaction.user.id);
        if (!game) return interaction.reply({ content: '❌ Jogo não encontrado!', ephemeral: true });

        await endGame(interaction.user.id, client, 'stand');
        await interaction.deferUpdate();
    }
};