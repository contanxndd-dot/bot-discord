const { EmbedBuilder } = require('discord.js');
const economy = require('../../utils/economyManager');

module.exports = {
    name: 'daily',
    description: 'Pega seu bônus diário de sonhos',
    async execute(message, args, client) {
        if (!economy.canDaily(message.guild.id, message.author.id)) {
            const remaining = economy.getCooldown(message.guild.id, message.author.id);
            const hours = Math.floor(remaining / 3600000);
            const minutes = Math.floor((remaining % 3600000) / 60000);
            
            return message.reply(`⏰ Você já pegou seu daily!\nVolte em **${hours}h ${minutes}min**`);
        }

        const bonus = economy.setDaily(message.guild.id, message.author.id);
        const balance = economy.getBalance(message.guild.id, message.author.id);

        const embed = new EmbedBuilder()
            .setColor('#FFD700')
            .setTitle('☀️ Daily Coletado!')
            .setDescription(`${message.author} coletou seus sonhos diários!`)
            .addFields(
                { name: '💎 Ganho', value: `+${bonus} sonhos`, inline: true },
                { name: '💰 Saldo', value: `${balance} sonhos`, inline: true }
            )
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    }
};