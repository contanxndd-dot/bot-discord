const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const giveawayManager = require('../../utils/giveawayManager');

module.exports = {
    name: 'giveaway',
    description: 'Sistema de sorteios',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageEvents)) {
            return message.reply('❌ Sem permissão!');
        }

        const sub = args[0]?.toLowerCase();

        switch (sub) {
            case 'iniciar':
            case 'start':
                await giveawayManager.create(message, args.slice(1), client);
                break;

            case 'encerrar':
            case 'end':
                const messageId = args[1];
                if (!messageId) return message.reply('❌ Forneça o ID da mensagem do sorteio!');
                await giveawayManager.end(messageId, client);
                break;

            case 'reroll':
                await rerollGiveaway(message, args[1], client);
                break;

            default:
                const embed = new EmbedBuilder()
                    .setColor('#FF00FF')
                    .setTitle('🎉 Comandos de Sorteio')
                    .addFields(
                        { name: '!giveaway iniciar', value: '`!giveaway iniciar <tempo> <ganhadores> <prêmio>`\nEx: `!giveaway iniciar 10m 1 Nitro`' },
                        { name: '!giveaway encerrar', value: '`!giveaway encerrar <id_mensagem>`' },
                        { name: '!giveaway reroll', value: '`!giveaway reroll <id_mensagem>`' },
                        { name: '⏰ Formatos', value: '`10s` segundos | `10m` minutos | `2h` horas | `1d` dias' }
                    );
                message.channel.send({ embeds: [embed] });
        }
    }
};

async function rerollGiveaway(message, messageId, client) {
    if (!messageId) return message.reply('❌ Forneça o ID da mensagem do sorteio!');

    try {
        const giveawayMessage = await message.channel.messages.fetch(messageId);
        const reaction = giveawayMessage.reactions.cache.get('🎉');
        if (!reaction) return message.reply('❌ Sorteio não encontrado!');

        const users = await reaction.users.fetch();
        const participants = users.filter(u => !u.bot);

        if (participants.size === 0) return message.reply('❌ Nenhum participante!');

        const winner = Array.from(participants.values())[Math.floor(Math.random() * participants.size)];
        message.channel.send(`🎉 Novo ganhador: ${winner}!`);
    } catch (error) {
        message.reply('❌ Mensagem de sorteio não encontrada!');
    }
}