const { EmbedBuilder } = require('discord.js');
const levelManager = require('../../utils/levelManager');

module.exports = {
    name: 'rank',
    description: 'Mostra seu nível e XP',
    async execute(message, args, client) {
        const user = message.mentions.users.first() || message.author;
        const rankData = levelManager.getRank(message.guild.id, user.id);

        if (!rankData) {
            return message.reply('❌ Este usuário ainda não tem XP!');
        }

        const currentXp = rankData.xp;
        const nextLevelXp = rankData.nextLevelXp;
        const progress = Math.floor((currentXp / nextLevelXp) * 20);
        const bar = '🟩'.repeat(progress) + '⬛'.repeat(20 - progress);

        const embed = new EmbedBuilder()
            .setColor('#FFD700')
            .setTitle(`🏆 Rank de ${user.username}`)
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .addFields(
                { name: '📊 Nível', value: `${rankData.level}`, inline: true },
                { name: '📈 XP Total', value: `${currentXp}`, inline: true },
                { name: '💬 Mensagens', value: `${rankData.messages}`, inline: true },
                { name: '🏅 Posição', value: `#${rankData.rank}`, inline: true },
                { name: '📊 Progresso', value: `${bar}\n${currentXp}/${nextLevelXp} XP` }
            )
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    }
};