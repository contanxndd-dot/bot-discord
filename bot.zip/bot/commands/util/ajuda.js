const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'ajuda',
    description: 'Mostra todos os comandos',
    async execute(message, args, client) {
        const prefix = '!';
        
        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('📚 Comandos do Bot')
            .setDescription(`Prefixo: \`${prefix}\``)
            .addFields(
                { 
                    name: '🛡️ Moderação', 
                    value: '`ban`, `hackban`, `unban`, `kick`, `mute`, `clear`, `warn`, `warns`, `delwarn`, `lock`, `unlock`' 
                },
                { 
                    name: '🎫 Tickets', 
                    value: '`ticket criar`, `ticket fechar`, `ticket add`, `ticket remove`, `ticket config`' 
                },
                { 
                    name: '🎉 Sorteios', 
                    value: '`giveaway iniciar`, `giveaway encerrar`, `giveaway reroll`' 
                },
                { 
                    name: '📢 Anúncios', 
                    value: '`anuncio enviar`, `anuncio rapido`, `anuncio canal`' 
                },
                { 
                    name: '🛡️ Proteção', 
                    value: '`antiraid`, `whitelist`, `blacklist`, `lockall`, `unlockall`' 
                },
                { 
                    name: '⚙️ Configuração', 
                    value: '`config`, `setprefix`, `setlogs`, `setwelcome`, `setgoodbye`, `setmodlogs`, `setautomod`' 
                },
                { 
                    name: '🔧 Utilidade', 
                    value: '`afk`, `userinfo`, `serverinfo`, `ping`' 
                }
            )
            .setFooter({ text: `Use ${prefix}ajuda para ver novamente` });

        message.channel.send({ embeds: [embed] });
    }
};