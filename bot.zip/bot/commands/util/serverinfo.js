const { EmbedBuilder, ChannelType } = require('discord.js');

module.exports = {
    name: 'serverinfo',
    description: 'Mostra informações do servidor',
    async execute(message, args, client) {
        const guild = message.guild;
        const owner = await guild.fetchOwner();
        
        const textChannels = guild.channels.cache.filter(c => c.type === ChannelType.GuildText).size;
        const voiceChannels = guild.channels.cache.filter(c => c.type === ChannelType.GuildVoice).size;
        const bots = guild.members.cache.filter(m => m.user.bot).size;
        const humans = guild.memberCount - bots;

        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle(`📊 ${guild.name}`)
            .setThumbnail(guild.iconURL({ dynamic: true }))
            .addFields(
                { name: '👑 Dono', value: owner.user.tag, inline: true },
                { name: '🆔 ID', value: guild.id, inline: true },
                { name: '📅 Criado em', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true },
                { name: '👥 Membros', value: `${guild.memberCount} (${humans} humanos, ${bots} bots)`, inline: true },
                { name: '💬 Canais', value: `${textChannels} texto | ${voiceChannels} voz`, inline: true },
                { name: '😀 Emojis', value: `${guild.emojis.cache.size}`, inline: true },
                { name: '🎭 Cargos', value: `${guild.roles.cache.size}`, inline: true },
                { name: '💎 Boosts', value: `Nível ${guild.premiumTier} (${guild.premiumSubscriptionCount} boosts)`, inline: true }
            )
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    }
};