const { 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    ChannelType, 
    PermissionsBitField,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle
} = require('discord.js');
const db = require('../../utils/database');

module.exports = {
    name: 'ticket',
    description: 'Sistema de tickets',
    async execute(message, args, client) {
        const sub = args[0]?.toLowerCase();
        const isAdmin = message.member.permissions.has(PermissionsBitField.Flags.Administrator);

        switch (sub) {
            case 'criar':
            case 'setup':
                if (!isAdmin) return message.reply('❌ Apenas administradores!');
                await criarPainel(message, client);
                break;

            case 'fechar':
            case 'close':
                await fecharTicket(message, client);
                break;

            case 'add':
                await adicionarPessoa(message, args);
                break;

            case 'remove':
                await removerPessoa(message, args);
                break;

            case 'config':
                if (!isAdmin) return message.reply('❌ Apenas administradores!');
                await configurarSuporte(message, args);
                break;

            default:
                const ajuda = new EmbedBuilder()
                    .setColor('#5865F2')
                    .setTitle('🎫 Sistema de Tickets')
                    .setDescription([
                        '**Comandos:**',
                        '`!ticket criar` - Cria o painel de tickets',
                        '`!ticket config @cargo` - Define cargo de suporte',
                        '`!ticket fechar` - Fecha o ticket atual',
                        '`!ticket add @user` - Adiciona pessoa',
                        '`!ticket remove @user` - Remove pessoa',
                        '',
                        '**Personalizar mensagem:**',
                        '`!setticketmsg titulo <texto>`',
                        '`!setticketmsg descricao <texto>`',
                        '`!setticketmsg botao <texto>`'
                    ].join('\n'));
                message.channel.send({ embeds: [ajuda] });
        }
    },

    async handleInteraction(interaction, client) {
        if (interaction.customId === 'abrir_ticket') {
            await abrirModal(interaction);
        }

        if (interaction.customId === 'fechar_ticket') {
            await confirmarFechamento(interaction);
        }

        if (interaction.customId === 'confirmar_fechar') {
            await fecharTicketProcesso(interaction.channel, interaction.user, client);
            await interaction.update({ content: '🔒 Ticket sendo fechado...', components: [], embeds: [] });
        }

        if (interaction.customId === 'cancelar_fechar') {
            await interaction.update({ content: '✅ Fechamento cancelado', components: [], embeds: [] });
            setTimeout(() => interaction.deleteReply().catch(() => {}), 3000);
        }

        if (interaction.customId === 'modal_ticket') {
            await criarTicket(interaction, client);
        }
    }
};

async function criarPainel(message, client) {
    const config = db.getGuildConfig(message.guild.id);
    
    const titulo = config.ticketTitle || '🎫 Central de Atendimento';
    const descricao = config.ticketDescription || 'Precisa de ajuda? Abra um ticket!\n\n1️⃣ Clique no botão abaixo\n2️⃣ Preencha o formulário\n3️⃣ Um canal privado será criado\n\n⚠️ Seja claro e educado';
    const textoBotao = config.ticketButton || 'Abrir Ticket';

    const embed = new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle(titulo)
        .setDescription(descricao)
        .setTimestamp();

    const botao = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('abrir_ticket')
                .setLabel(textoBotao)
                .setStyle(ButtonStyle.Primary)
                .setEmoji('🎫')
        );

    const msg = await message.channel.send({ embeds: [embed], components: [botao] });

    config.ticketPanelChannel = message.channel.id;
    config.ticketPanelMessage = msg.id;
    db.updateGuildConfig(message.guild.id, config);

    message.channel.send('✅ Painel de tickets criado!');
}

async function abrirModal(interaction) {
    const guild = interaction.guild;
    const user = interaction.user;
    
    const ticketExistente = guild.channels.cache.find(
        c => c.topic && c.topic.includes(`Dono: ${user.id}`)
    );

    if (ticketExistente) {
        return interaction.reply({
            content: `❌ Você já tem um ticket aberto! ${ticketExistente}`,
            ephemeral: true
        });
    }

    const modal = new ModalBuilder()
        .setCustomId('modal_ticket')
        .setTitle('🎫 Abrir Ticket');

    const tituloInput = new TextInputBuilder()
        .setCustomId('titulo')
        .setLabel('📝 Título do problema')
        .setPlaceholder('Ex: Preciso de ajuda com comandos')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMinLength(5)
        .setMaxLength(100);

    const descricaoInput = new TextInputBuilder()
        .setCustomId('descricao')
        .setLabel('📄 Descreva seu problema')
        .setPlaceholder('Explique com detalhes...')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(true)
        .setMinLength(10)
        .setMaxLength(1000);

    const linha1 = new ActionRowBuilder().addComponents(tituloInput);
    const linha2 = new ActionRowBuilder().addComponents(descricaoInput);

    modal.addComponents(linha1, linha2);

    await interaction.showModal(modal);
}

async function criarTicket(interaction, client) {
    const guild = interaction.guild;
    const user = interaction.user;
    const config = db.getGuildConfig(guild.id);

    const titulo = interaction.fields.getTextInputValue('titulo');
    const descricao = interaction.fields.getTextInputValue('descricao');

    await interaction.reply({ content: '⏳ Criando seu ticket...', ephemeral: true });

    try {
        let categoria = guild.channels.cache.get(config.ticketCategory);
        
        if (!categoria) {
            categoria = await guild.channels.create({
                name: '🎫 TICKETS',
                type: ChannelType.GuildCategory,
                permissionOverwrites: [
                    { id: guild.roles.everyone.id, deny: [PermissionsBitField.Flags.ViewChannel] },
                    { id: client.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.ManageChannels, PermissionsBitField.Flags.SendMessages] }
                ]
            });
            db.setGuildConfig(guild.id, 'ticketCategory', categoria.id);
        }

        const nomeCanal = `ticket-${user.username.toLowerCase().replace(/[^a-z0-9]/g, '')}`;
        
        const canalTicket = await guild.channels.create({
            name: nomeCanal,
            type: ChannelType.GuildText,
            parent: categoria.id,
            topic: `Dono: ${user.id} | Aberto em: ${new Date().toLocaleString('pt-BR')}`,
            permissionOverwrites: [
                { id: guild.roles.everyone.id, deny: [PermissionsBitField.Flags.ViewChannel] },
                { id: user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory] },
                { id: client.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ManageChannels] }
            ]
        });

        if (config.ticketSupportRole) {
            await canalTicket.permissionOverwrites.create(config.ticketSupportRole, {
                ViewChannel: true,
                SendMessages: true,
                ReadMessageHistory: true
            });
        }

        const embedTicket = new EmbedBuilder()
            .setColor('#5865F2')
            .setTitle('🎫 Novo Ticket')
            .setDescription([
                `**📝 Título:** ${titulo}`,
                '',
                '━━━━━━━━━━━━━━━━━━━',
                '',
                '**📄 Descrição:**',
                descricao,
                '',
                '━━━━━━━━━━━━━━━━━━━',
                '',
                `👤 **Aberto por:** ${user}`,
                `📅 **Data:** ${new Date().toLocaleString('pt-BR')}`,
                '',
                '📌 Aguarde o atendimento.'
            ].join('\n'))
            .setTimestamp();

        const botoes = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('fechar_ticket')
                    .setLabel('Fechar Ticket')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🔒')
            );

        const ping = config.ticketSupportRole ? `<@&${config.ticketSupportRole}>` : '';
        
        await canalTicket.send({
            content: `${user} ${ping}`,
            embeds: [embedTicket],
            components: [botoes]
        });

        await interaction.editReply({ content: `✅ Ticket criado! ${canalTicket}` });

        if (client.sendLog) {
            const logEmbed = new EmbedBuilder()
                .setColor('#5865F2')
                .setTitle('🎫 Ticket Aberto')
                .addFields(
                    { name: '👤 Usuário', value: user.tag },
                    { name: '📝 Título', value: titulo },
                    { name: '💬 Canal', value: canalTicket.toString() }
                )
                .setTimestamp();
            await client.sendLog(guild, logEmbed);
        }

    } catch (error) {
        console.error('Erro ao criar ticket:', error);
        await interaction.editReply({ content: '❌ Erro ao criar ticket.' }).catch(() => {});
    }
}

async function confirmarFechamento(interaction) {
    if (!interaction.channel.name.startsWith('ticket-')) {
        return interaction.reply({ content: '❌ Use em um canal de ticket!', ephemeral: true });
    }

    const embed = new EmbedBuilder()
        .setColor('#FF0000')
        .setTitle('🔒 Fechar Ticket')
        .setDescription('**Tem certeza?**\n⚠️ O canal será deletado!');

    const botoes = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder().setCustomId('confirmar_fechar').setLabel('Sim, Fechar').setStyle(ButtonStyle.Danger).setEmoji('✅'),
            new ButtonBuilder().setCustomId('cancelar_fechar').setLabel('Cancelar').setStyle(ButtonStyle.Secondary).setEmoji('❌')
        );

    await interaction.reply({ embeds: [embed], components: [botoes], ephemeral: true });
}

async function fecharTicket(message, client) {
    if (!message.channel.name.startsWith('ticket-')) {
        return message.reply('❌ Este comando só funciona em canais de ticket!');
    }
    await fecharTicketProcesso(message.channel, message.author, client);
}

async function fecharTicketProcesso(channel, user, client) {
    try {
        const mensagens = await channel.messages.fetch({ limit: 100 });
        
        let transcricao = `📝 Transcrição: ${channel.name}\nFechado por: ${user.tag}\nData: ${new Date().toLocaleString('pt-BR')}\n${'='.repeat(50)}\n\n`;

        const mensagensOrdenadas = Array.from(mensagens.values()).reverse();
        for (const msg of mensagensOrdenadas) {
            transcricao += `[${new Date(msg.createdTimestamp).toLocaleString('pt-BR')}] ${msg.author.tag}: ${msg.content || '[Sem conteúdo]'}\n`;
        }

        const config = db.getGuildConfig(channel.guild.id);
        if (config.logChannel) {
            const canalLogs = channel.guild.channels.cache.get(config.logChannel);
            if (canalLogs) {
                const buffer = Buffer.from(transcricao, 'utf-8');
                await canalLogs.send({
                    embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('🔒 Ticket Fechado').addFields({ name: '📝 Canal', value: channel.name }, { name: '👤 Fechado por', value: user.tag }).setTimestamp()],
                    files: [{ attachment: buffer, name: `transcricao-${channel.name}.txt` }]
                }).catch(() => {});
            }
        }

        await channel.send({ embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('🔒 Ticket Fechado').setDescription('Canal será deletado em 5s...')] });

        setTimeout(async () => { await channel.delete().catch(() => {}); }, 5000);
    } catch (error) {
        console.error('Erro ao fechar ticket:', error);
    }
}

async function adicionarPessoa(message, args) {
    if (!message.channel.name.startsWith('ticket-')) return message.reply('❌ Use em um canal de ticket!');
    const user = message.mentions.users.first();
    if (!user) return message.reply('❌ Mencione um usuário!');

    await message.channel.permissionOverwrites.create(user.id, {
        ViewChannel: true, SendMessages: true, ReadMessageHistory: true
    });

    message.channel.send({ embeds: [new EmbedBuilder().setColor('#00FF00').setDescription(`✅ ${user} adicionado por ${message.author}`)] });
}

async function removerPessoa(message, args) {
    if (!message.channel.name.startsWith('ticket-')) return message.reply('❌ Use em um canal de ticket!');
    const user = message.mentions.users.first();
    if (!user) return message.reply('❌ Mencione um usuário!');

    const donoId = message.channel.topic?.match(/Dono: (\d+)/)?.[1];
    if (user.id === donoId) return message.reply('❌ Não pode remover o dono!');

    await message.channel.permissionOverwrites.delete(user.id);
    message.channel.send({ embeds: [new EmbedBuilder().setColor('#FF0000').setDescription(`✅ ${user} removido por ${message.author}`)] });
}

async function configurarSuporte(message, args) {
    const cargo = message.mentions.roles.first();
    if (!cargo) return message.reply('❌ Mencione um cargo!\nEx: `!ticket config @Suporte`');
    db.setGuildConfig(message.guild.id, 'ticketSupportRole', cargo.id);
    message.channel.send({ embeds: [new EmbedBuilder().setColor('#00FF00').setDescription(`✅ Cargo de suporte: ${cargo}`)] });
}