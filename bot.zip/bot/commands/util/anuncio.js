const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const db = require('../../utils/database');

module.exports = {
    name: 'anuncio',
    description: 'Cria anúncios formatados',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return message.reply('❌ Sem permissão!');
        }

        const sub = args[0]?.toLowerCase();

        switch (sub) {
            case 'enviar':
            case 'send':
                await sendAnnouncement(message, args.slice(1), client);
                break;

            case 'canal':
                if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                    return message.reply('❌ Apenas administradores!');
                }
                const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
                if (!channel) return message.reply('❌ Mencione um canal!');
                db.setGuildConfig(message.guild.id, 'announceChannel', channel.id);
                message.channel.send(`✅ Canal de anúncios: ${channel}`);
                break;

            case 'rapido':
            case 'quick':
                const quickText = args.slice(1).join(' ');
                if (!quickText) return message.reply('❌ Forneça a mensagem!');
                const quickEmbed = new EmbedBuilder()
                    .setColor('#0099ff')
                    .setTitle('📢 Anúncio')
                    .setDescription(quickText)
                    .setTimestamp();
                await message.channel.send({ embeds: [quickEmbed] });
                if (message.deletable) await message.delete().catch(() => {});
                break;

            default:
                const embed = new EmbedBuilder()
                    .setColor('#0099ff')
                    .setTitle('📢 Sistema de Anúncios')
                    .setDescription([
                        '**Comandos:**',
                        '`!anuncio enviar <tipo> <título> | <mensagem>`',
                        'Tipos: `normal`, `importante`, `atualizacao`, `evento`, `regra`',
                        '',
                        '`!anuncio rapido <mensagem>` - Anúncio rápido',
                        '`!anuncio canal #canal` - Definir canal padrão (Admin)',
                        '',
                        '**Exemplo:**',
                        '`!anuncio enviar importante Nova Regra | Proibido spam`'
                    ].join('\n'));
                message.channel.send({ embeds: [embed] });
        }
    }
};

async function sendAnnouncement(message, args, client) {
    const type = args[0]?.toLowerCase();
    const text = args.slice(1).join(' ');
    
    if (!type || !text) {
        return message.reply('❌ Use: `!anuncio enviar <tipo> <título> | <mensagem>`');
    }

    const parts = text.split('|').map(p => p.trim());
    const title = parts[0] || 'Anúncio';
    const description = parts[1] || parts[0];

    const config = db.getGuildConfig(message.guild.id);
    const channelId = config.announceChannel || message.channel.id;
    const channel = message.guild.channels.cache.get(channelId);
    if (!channel) return message.reply('❌ Canal não encontrado!');

    let embed = new EmbedBuilder().setTimestamp();
    let mention = '';

    switch (type) {
        case 'importante':
            embed.setColor('#FF0000').setTitle('🚨 ' + title).setDescription(description);
            mention = '@everyone';
            break;
        case 'atualizacao':
            embed.setColor('#00FF00').setTitle('🔄 ' + title).setDescription(description);
            break;
        case 'evento':
            embed.setColor('#FF00FF').setTitle('🎉 ' + title).setDescription(description);
            break;
        case 'regra':
            embed.setColor('#FFA500').setTitle('📋 ' + title).setDescription(description);
            break;
        default:
            embed.setColor('#0099ff').setTitle('📢 ' + title).setDescription(description);
    }

    embed.setFooter({ text: `Anunciado por ${message.author.tag}` });

    try {
        if (mention) {
            await channel.send({ content: mention, embeds: [embed] });
        } else {
            await channel.send({ embeds: [embed] });
        }
        if (channel.id !== message.channel.id) {
            message.channel.send(`✅ Anúncio enviado em ${channel}!`);
        }
    } catch (error) {
        message.reply('❌ Erro ao enviar anúncio!');
    }
}