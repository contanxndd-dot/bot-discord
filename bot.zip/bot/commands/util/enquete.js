const { PermissionsBitField, EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'enquete',
    description: 'Cria uma enquete com reações',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return message.reply('❌ Sem permissão!');
        }

        const text = args.join(' ');
        if (!text) {
            return message.reply('❌ Use: `!enquete "Pergunta" "Opção1" "Opção2" ...`');
        }

        const parts = text.match(/"([^"]+)"/g);
        if (!parts || parts.length < 2) {
            return message.reply('❌ Use aspas!\nEx: `!enquete "Melhor cor?" "Azul" "Vermelho"`');
        }

        const question = parts[0].replace(/"/g, '');
        const options = parts.slice(1).map(o => o.replace(/"/g, ''));

        if (options.length > 10) {
            return message.reply('❌ Máximo 10 opções!');
        }

        const emojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('🗳️ ' + question)
            .setDescription(
                options.map((opt, i) => `${emojis[i]} ${opt}`).join('\n')
            )
            .setFooter({ text: `Enquete por ${message.author.tag}` })
            .setTimestamp();

        const msg = await message.channel.send({ embeds: [embed] });

        for (let i = 0; i < options.length; i++) {
            await msg.react(emojis[i]);
        }
    }
};