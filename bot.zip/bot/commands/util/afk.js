module.exports = {
    name: 'afk',
    description: 'Define seu status como AFK',
    async execute(message, args, client) {
        const reason = args.join(' ') || 'Não especificado';
        
        client.afk.set(message.author.id, {
            username: message.author.username,
            reason: reason,
            timestamp: Date.now()
        });

        message.reply({
            content: `💤 Você está AFK: ${reason}`,
            allowedMentions: { repliedUser: false }
        });
    }
};