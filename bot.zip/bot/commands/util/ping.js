const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'ping',
    description: 'Mostra a latência do bot',
    async execute(message, args, client) {
        const msg = await message.channel.send('🏓 Ping?');
        
        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('🏓 Pong!')
            .addFields(
                { name: '📡 Latência do Bot', value: `${msg.createdTimestamp - message.createdTimestamp}ms` },
                { name: '🌐 Latência da API', value: `${Math.round(client.ws.ping)}ms` }
            );

        await msg.edit({ content: '', embeds: [embed] });
    }
};