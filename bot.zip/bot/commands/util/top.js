const { EmbedBuilder } = require('discord.js');
const levelManager = require('../../utils/levelManager');

module.exports = {
    name: 'top',
    description: 'Top 10 usuários com mais XP',
    async execute(message, args, client) {
        const top = levelManager.getTop(message.guild.id, 10);

        if (top.length === 0) {
            return message.reply('📭 Nenhum usuário com XP ainda!');
        }

        const medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

        const description = await Promise.all(top.map(async (user, index) => {
            const member = await client.users.fetch(user.userId).catch(() => null);
            const name = member ? member.username : 'Desconhecido';
            return `${medals[index]} **${name}** - Nível ${user.level} (${user.xp} XP)`;
        }));

        const embed = new EmbedBuilder()
            .setColor('#FFD700')
            .setTitle('🏆 Top 10 - Ranking do Servidor')
            .setDescription(description.join('\n'))
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    }
};