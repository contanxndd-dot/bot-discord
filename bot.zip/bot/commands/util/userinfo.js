const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'userinfo',
    description: 'Mostra informações do usuário',
    async execute(message, args, client) {
        const user = message.mentions.users.first() || message.author;
        const member = message.guild.members.cache.get(user.id);

        const statusMap = {
            online: '🟢 Online',
            idle: '🟡 Ausente',
            dnd: '🔴 Não perturbe',
            offline: '⚫ Offline'
        };

        const embed = new EmbedBuilder()
            .setColor(member?.displayHexColor || '#0099ff')
            .setTitle(`👤 ${user.tag}`)
            .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 1024 }))
            .addFields(
                { name: '🆔 ID', value: user.id, inline: true },
                { name: '🤖 Bot', value: user.bot ? 'Sim' : 'Não', inline: true },
                { name: '📅 Conta criada', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:D>`, inline: true }
            );

        if (member) {
            embed.addFields(
                { name: '📊 Status', value: statusMap[member.presence?.status] || '⚫ Offline', inline: true },
                { name: '📥 Entrou', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:D>`, inline: true },
                { name: '📛 Apelido', value: member.nickname || 'Nenhum', inline: true },
                { 
                    name: `🏷️ Cargos [${member.roles.cache.size - 1}]`, 
                    value: member.roles.cache.filter(r => r.id !== message.guild.id).map(r => r.toString()).join(' ').slice(0, 1024) || 'Nenhum'
                }
            );
        }

        message.channel.send({ embeds: [embed] });
    }
};