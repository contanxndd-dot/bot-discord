const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const db = require('../../utils/database');

const warnsFile = path.join(__dirname, '../../database/warns.json');

function getWarns() {
    try {
        if (!fs.existsSync(warnsFile)) return {};
        return JSON.parse(fs.readFileSync(warnsFile, 'utf8') || '{}');
    } catch { return {}; }
}

function saveWarns(data) {
    try {
        fs.writeFileSync(warnsFile, JSON.stringify(data, null, 2));
    } catch (error) {}
}

module.exports = {
    name: 'warn',
    description: 'Adverte um membro',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
            return message.reply('❌ Sem permissão!');
        }

        const user = message.mentions.users.first();
        if (!user) return message.reply('❌ Mencione um usuário!\nEx: `!warn @usuário [motivo]`');

        const reason = args.slice(1).join(' ') || 'Não especificado';
        const warns = getWarns();
        
        if (!warns[message.guild.id]) warns[message.guild.id] = {};
        if (!warns[message.guild.id][user.id]) warns[message.guild.id][user.id] = [];
        
        warns[message.guild.id][user.id].push({
            reason,
            moderator: message.author.tag,
            timestamp: Date.now()
        });
        
        saveWarns(warns);
        
        const warnCount = warns[message.guild.id][user.id].length;
        const config = db.getGuildConfig(message.guild.id);

        const embed = new EmbedBuilder()
            .setColor('#FFA500')
            .setTitle('⚠️ Advertência')
            .addFields(
                { name: 'Usuário', value: `${user.tag}`, inline: true },
                { name: 'Moderador', value: message.author.tag, inline: true },
                { name: 'Motivo', value: reason },
                { name: 'Total de Warns', value: `${warnCount}`, inline: true }
            )
            .setTimestamp();

        message.channel.send({ embeds: [embed] });

        const member = message.guild.members.cache.get(user.id);
        if (member) {
            if (warnCount >= config.maxWarnsBeforeBan) {
                await member.ban({ reason: 'Muitas advertências' }).catch(() => {});
                message.channel.send(`🔨 ${user} foi banido automaticamente!`);
            } else if (warnCount >= config.maxWarnsBeforeKick) {
                await member.kick('Muitas advertências').catch(() => {});
                message.channel.send(`👢 ${user} foi expulso automaticamente!`);
            } else if (warnCount >= config.maxWarnsBeforeMute) {
                await member.timeout(60 * 60 * 1000, 'Muitas advertências').catch(() => {});
                message.channel.send(`🔇 ${user} foi silenciado por 1h automaticamente!`);
            }
        }

        if (client.sendLog) {
            client.sendLog(message.guild, embed);
        }
    }
};