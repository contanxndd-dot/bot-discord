const { PermissionsBitField, EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'lock',
    description: 'Tranca o canal',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
            return message.reply('❌ Sem permissão!');
        }

        const channel = message.mentions.channels.first() || message.channel;

        try {
            await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                SendMessages: false
            });

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('🔒 Canal Trancado')
                .setDescription(`Canal trancado por ${message.author}`)
                .setTimestamp();

            await channel.send({ embeds: [embed] });
            
            if (channel.id !== message.channel.id) {
                message.channel.send(`✅ ${channel} trancado!`);
            }
        } catch (error) {
            message.reply('❌ Não foi possível trancar o canal!');
        }
    }
};