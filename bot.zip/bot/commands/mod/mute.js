const { PermissionsBitField, EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'mute',
    description: 'Silencia um membro',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
            return message.reply('❌ Sem permissão!');
        }

        const user = message.mentions.users.first();
        if (!user) return message.reply('❌ Mencione um usuário!\nEx: `!mute @usuário [minutos] [motivo]`');

        const member = message.guild.members.cache.get(user.id);
        if (!member) return message.reply('❌ Usuário não encontrado!');

        const time = parseInt(args[1]) || 10;
        const reason = args.slice(2).join(' ') || 'Não especificado';

        if (time > 40320) return message.reply('❌ Máximo: 28 dias (40320 min)');

        await member.timeout(time * 60 * 1000, reason);

        const embed = new EmbedBuilder()
            .setColor('#FFA500')
            .setTitle('🔇 Usuário Silenciado')
            .addFields(
                { name: 'Usuário', value: user.tag, inline: true },
                { name: 'Tempo', value: `${time} min`, inline: true },
                { name: 'Moderador', value: message.author.tag, inline: true },
                { name: 'Motivo', value: reason }
            )
            .setTimestamp();

        message.channel.send({ embeds: [embed] });

        if (client.sendLog) {
            client.sendLog(message.guild, embed);
        }
    }
};