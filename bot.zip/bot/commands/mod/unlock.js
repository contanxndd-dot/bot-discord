const { PermissionsBitField, EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'unlock',
    description: 'Destranca o canal',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
            return message.reply('❌ Sem permissão!');
        }

        const channel = message.mentions.channels.first() || message.channel;

        try {
            await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                SendMessages: null
            });

            const embed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('🔓 Canal Destrancado')
                .setDescription(`Canal destrancado por ${message.author}`)
                .setTimestamp();

            await channel.send({ embeds: [embed] });
            
            if (channel.id !== message.channel.id) {
                message.channel.send(`✅ ${channel} destrancado!`);
            }
        } catch (error) {
            message.reply('❌ Não foi possível destrancar o canal!');
        }
    }
};