const { PermissionsBitField } = require('discord.js');
const fs = require('fs');
const path = require('path');

const warnsFile = path.join(__dirname, '../../database/warns.json');

module.exports = {
    name: 'delwarn',
    description: 'Remove uma advertência',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
            return message.reply('❌ Sem permissão!');
        }

        const user = message.mentions.users.first();
        const index = parseInt(args[1]);

        if (!user || isNaN(index)) {
            return message.reply('❌ Use: `!delwarn @usuário [número]`\nEx: `!delwarn @user 3`');
        }

        try {
            const data = JSON.parse(fs.readFileSync(warnsFile, 'utf8'));
            const userWarns = data[message.guild.id]?.[user.id];

            if (!userWarns || userWarns.length === 0) {
                return message.reply('❌ Usuário não tem warns!');
            }

            if (index < 1 || index > userWarns.length) {
                return message.reply(`❌ Use um número entre 1 e ${userWarns.length}!`);
            }

            userWarns.splice(index - 1, 1);
            fs.writeFileSync(warnsFile, JSON.stringify(data, null, 2));

            message.channel.send(`✅ Warn #${index} de ${user.tag} removida!`);
        } catch (error) {
            message.reply('❌ Erro ao remover warn!');
        }
    }
};