const { PermissionsBitField, EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'ban',
    description: 'Bane um membro',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.BanMembers)) {
            return message.reply('❌ Sem permissão!');
        }

        const user = message.mentions.users.first();
        if (!user) return message.reply('❌ Mencione um usuário!\nEx: `!ban @usuário [motivo]`');

        const member = message.guild.members.cache.get(user.id);
        if (!member) return message.reply('❌ Usuário não está no servidor!');
        if (!member.bannable) return message.reply('❌ Não posso banir este usuário!');

        const reason = args.slice(1).join(' ') || 'Não especificado';

        await member.ban({ reason });

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('🔨 Usuário Banido')
            .addFields(
                { name: 'Usuário', value: `${user.tag} (${user.id})` },
                { name: 'Moderador', value: message.author.tag },
                { name: 'Motivo', value: reason }
            )
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
        
        if (client.sendLog) {
            client.sendLog(message.guild, embed);
        }
    }
};