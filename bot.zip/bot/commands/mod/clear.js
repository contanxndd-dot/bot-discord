const { PermissionsBitField } = require('discord.js');

module.exports = {
    name: 'clear',
    description: 'Limpa mensagens',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return message.reply('❌ Sem permissão!');
        }

        const amount = parseInt(args[0]);
        if (!amount || amount < 1 || amount > 100) {
            return message.reply('❌ Use um número entre 1 e 100!\nEx: `!clear 10`');
        }

        try {
            await message.channel.bulkDelete(amount, true);
            const msg = await message.channel.send(`✅ ${amount} mensagens limpas!`);
            setTimeout(() => msg.delete().catch(() => {}), 3000);
        } catch (error) {
            message.reply('❌ Erro ao limpar mensagens!');
        }
    }
};