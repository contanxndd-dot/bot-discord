const { PermissionsBitField, EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'unban',
    description: 'Desbane um usuário',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.BanMembers)) {
            return message.reply('❌ Sem permissão!');
        }

        const userId = args[0];
        if (!userId) return message.reply('❌ Forneça um ID!\nEx: `!unban 123456789`');

        try {
            await message.guild.members.unban(userId);

            const embed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('✅ Usuário Desbanido')
                .addFields(
                    { name: 'ID', value: userId },
                    { name: 'Moderador', value: message.author.tag }
                )
                .setTimestamp();

            message.channel.send({ embeds: [embed] });

            if (client.sendLog) {
                client.sendLog(message.guild, embed);
            }
        } catch (error) {
            message.reply('❌ Usuário não está banido ou ID inválido!');
        }
    }
};