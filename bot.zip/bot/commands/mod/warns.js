const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const warnsFile = path.join(__dirname, '../../database/warns.json');

module.exports = {
    name: 'warns',
    description: 'Mostra as advertências de um usuário',
    async execute(message, args, client) {
        const user = message.mentions.users.first() || message.author;
        
        try {
            const data = JSON.parse(fs.readFileSync(warnsFile, 'utf8') || '{}');
            const guildWarns = data[message.guild.id]?.[user.id] || [];

            if (guildWarns.length === 0) {
                return message.reply(`✅ ${user} não tem advertências!`);
            }

            const embed = new EmbedBuilder()
                .setColor('#FFA500')
                .setTitle(`📋 Warns de ${user.tag}`)
                .setDescription(`Total: **${guildWarns.length}**`);

            const recent = guildWarns.slice(-10);
            recent.forEach((warn, i) => {
                embed.addFields({
                    name: `⚠️ Warn #${i + 1}`,
                    value: `📝 ${warn.reason}\n🛡️ ${warn.moderator}\n📅 <t:${Math.floor(warn.timestamp / 1000)}:R>`
                });
            });

            message.channel.send({ embeds: [embed] });
        } catch (error) {
            message.reply('✅ Nenhuma advertência encontrada!');
        }
    }
};