const { PermissionsBitField, EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'kick',
    description: 'Expulsa um membro',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.KickMembers)) {
            return message.reply('❌ Sem permissão!');
        }

        const user = message.mentions.users.first();
        if (!user) return message.reply('❌ Mencione um usuário!\nEx: `!kick @usuário [motivo]`');

        const member = message.guild.members.cache.get(user.id);
        if (!member) return message.reply('❌ Usuário não encontrado!');
        if (!member.kickable) return message.reply('❌ Não posso expulsar!');

        const reason = args.slice(1).join(' ') || 'Não especificado';
        await member.kick(reason);

        const embed = new EmbedBuilder()
            .setColor('#FFA500')
            .setTitle('👢 Usuário Expulso')
            .addFields(
                { name: 'Usuário', value: user.tag },
                { name: 'Moderador', value: message.author.tag },
                { name: 'Motivo', value: reason }
            )
            .setTimestamp();

        message.channel.send({ embeds: [embed] });

        if (client.sendLog) {
            client.sendLog(message.guild, embed);
        }
    }
};