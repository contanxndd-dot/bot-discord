const { PermissionsBitField, EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'hackban',
    description: 'Bane um usuário por ID',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.BanMembers)) {
            return message.reply('❌ Sem permissão!');
        }

        const userId = args[0];
        if (!userId || !userId.match(/^\d{17,19}$/)) {
            return message.reply('❌ Forneça um ID válido!\nEx: `!hackban 123456789 [motivo]`');
        }

        const reason = args.slice(1).join(' ') || 'Não especificado';

        try {
            await message.guild.members.ban(userId, { reason });

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('🔨 HackBan')
                .addFields(
                    { name: 'ID', value: userId },
                    { name: 'Moderador', value: message.author.tag },
                    { name: 'Motivo', value: reason }
                )
                .setTimestamp();

            message.channel.send({ embeds: [embed] });

            if (client.sendLog) {
                client.sendLog(message.guild, embed);
            }
        } catch (error) {
            message.reply('❌ Não foi possível banir. Verifique o ID!');
        }
    }
};