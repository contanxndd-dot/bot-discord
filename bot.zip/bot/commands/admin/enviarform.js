const { PermissionsBitField, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');

const formsFile = path.join(__dirname, '../../database/forms.json');

module.exports = {
    name: 'enviarform',
    description: 'Envia a mensagem fixa do formulário',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('❌ Apenas administradores!');
        }

        const nome = args[0]?.toLowerCase();
        const channel = message.mentions.channels.first() || message.channel;

        if (!nome) {
            return message.reply('❌ Use: `!enviarform <nome> #canal`');
        }

        let forms = {};
        try {
            if (fs.existsSync(formsFile)) {
                forms = JSON.parse(fs.readFileSync(formsFile, 'utf8') || '{}');
            }
        } catch (error) {}

        const form = forms[message.guild.id]?.[nome];
        if (!form) return message.reply('❌ Formulário não encontrado!');

        const embed = new EmbedBuilder()
            .setColor('#5865F2')
            .setTitle(`📋 ${form.titulo}`)
            .setDescription([
                '**Estamos recrutando!**',
                '',
                'Clique no botão abaixo para se inscrever.',
                '',
                `📝 **${form.perguntas.length} perguntas**`,
                '',
                '⚠️ Seja honesto e completo nas respostas!'
            ].join('\n'))
            .setFooter({ text: `Formulário: ${nome}` })
            .setTimestamp();

        const button = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`form_${nome}`)
                    .setLabel('📝 Inscrever-se')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('📋')
            );

        await channel.send({ embeds: [embed], components: [button] });

        message.channel.send(`✅ Painel enviado em ${channel}!\n🔄 Reenviar: \`!enviarform ${nome} #canal\``);
    }
};