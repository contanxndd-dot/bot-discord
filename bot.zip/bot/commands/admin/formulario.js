const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const formsFile = path.join(__dirname, '../../database/forms.json');

function getForms() {
    try {
        if (!fs.existsSync(formsFile)) return {};
        return JSON.parse(fs.readFileSync(formsFile, 'utf8') || '{}');
    } catch { return {}; }
}

function saveForms(data) {
    fs.writeFileSync(formsFile, JSON.stringify(data, null, 2));
}

module.exports = {
    name: 'formulario',
    description: 'Cria formulários personalizados',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('❌ Apenas administradores!');
        }

        const sub = args[0]?.toLowerCase();

        switch (sub) {
            case 'criar':
                const nome = args[1]?.toLowerCase();
                const titulo = args.slice(2).join(' ');
                if (!nome || !titulo) return message.reply('❌ Use: `!formulario criar <nome> <título>`');
                
                const forms = getForms();
                if (!forms[message.guild.id]) forms[message.guild.id] = {};
                if (forms[message.guild.id][nome]) return message.reply('❌ Já existe!');
                
                forms[message.guild.id][nome] = {
                    titulo, perguntas: [], criador: message.author.id, criadoEm: Date.now(), respostas: []
                };
                saveForms(forms);
                message.channel.send(`✅ Formulário **${nome}** criado!\nAdicione perguntas: \`!formulario pergunta ${nome} "Pergunta"\``);
                break;

            case 'pergunta':
                const nome2 = args[1]?.toLowerCase();
                const pergunta = args.slice(2).join(' ');
                if (!nome2 || !pergunta) return message.reply('❌ Use: `!formulario pergunta <nome> <pergunta>`');
                
                const forms2 = getForms();
                if (!forms2[message.guild.id]?.[nome2]) return message.reply('❌ Formulário não encontrado!');
                
                forms2[message.guild.id][nome2].perguntas.push(pergunta);
                saveForms(forms2);
                message.channel.send(`✅ Pergunta adicionada ao **${nome2}**!\n📝 "${pergunta}"`);
                break;

            case 'canal':
                const channel = message.mentions.channels.first();
                if (!channel) return message.reply('❌ Mencione um canal!');
                const db = require('../../utils/database');
                db.setGuildConfig(message.guild.id, 'formChannel', channel.id);
                message.channel.send(`✅ Canal de respostas: ${channel}`);
                break;

            case 'cargo':
                const role = message.mentions.roles.first();
                if (!role) return message.reply('❌ Mencione um cargo!');
                const db2 = require('../../utils/database');
                db2.setGuildConfig(message.guild.id, 'formApprovalRole', role.id);
                message.channel.send(`✅ Cargo de aprovação: ${role}`);
                break;

            case 'ver':
                const forms3 = getForms();
                const gf = forms3[message.guild.id] || {};
                if (Object.keys(gf).length === 0) return message.reply('📭 Nenhum formulário!');
                
                const embed = new EmbedBuilder().setColor('#0099ff').setTitle('📋 Formulários');
                for (const [n, d] of Object.entries(gf)) {
                    embed.addFields({
                        name: `📝 ${n}`,
                        value: `Título: ${d.titulo}\nPerguntas: ${d.perguntas.length}\nEnviar: \`!enviarform ${n} #canal\``
                    });
                }
                message.channel.send({ embeds: [embed] });
                break;

            case 'deletar':
                const nome3 = args[1]?.toLowerCase();
                if (!nome3) return message.reply('❌ Use: `!formulario deletar <nome>`');
                const forms4 = getForms();
                if (!forms4[message.guild.id]?.[nome3]) return message.reply('❌ Não encontrado!');
                delete forms4[message.guild.id][nome3];
                saveForms(forms4);
                message.channel.send(`✅ **${nome3}** deletado!`);
                break;

            default:
                message.channel.send({ embeds: [new EmbedBuilder().setColor('#0099ff').setTitle('📋 Formulários')
                    .setDescription('`!formulario criar <nome> <título>` - Criar\n`!formulario pergunta <nome> <pergunta>` - Add pergunta\n`!formulario canal #canal` - Canal respostas\n`!formulario cargo @cargo` - Cargo aprovado\n`!formulario ver` - Ver todos\n`!formulario deletar <nome>` - Deletar\n\n**Enviar:** `!enviarform <nome> #canal`')]});
        }
    }
};