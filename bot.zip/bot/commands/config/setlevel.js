const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const db = require('../../utils/database');

module.exports = {
    name: 'setlevel',
    description: 'Configura o sistema de level',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('❌ Apenas administradores!');
        }

        const sub = args[0]?.toLowerCase();

        switch (sub) {
            case 'canal':
                const channel = message.mentions.channels.first();
                if (!channel) return message.reply('❌ Mencione um canal!\nEx: `!setlevel canal #level-up`');
                db.setGuildConfig(message.guild.id, 'levelChannel', channel.id);
                message.channel.send(`✅ Canal de level up: ${channel}`);
                break;

            case 'cargo':
                const level = parseInt(args[1]);
                const role = message.mentions.roles.first();
                
                if (!level || !role) {
                    return message.reply('❌ Use: `!setlevel cargo <nível> @cargo`\nEx: `!setlevel cargo 10 @VIP`');
                }

                const config = db.getGuildConfig(message.guild.id);
                if (!config.levelRewards) config.levelRewards = {};
                config.levelRewards[level] = role.id;
                db.updateGuildConfig(message.guild.id, config);

                message.channel.send(`✅ Nível ${level} = ${role}`);
                break;

            case 'ver':
                const cfg = db.getGuildConfig(message.guild.id);
                const embed = new EmbedBuilder()
                    .setColor('#FFD700')
                    .setTitle('📊 Configuração de Level')
                    .addFields(
                        { name: 'Canal de Anúncio', value: cfg.levelChannel ? `<#${cfg.levelChannel}>` : 'Não configurado' }
                    );
                
                if (cfg.levelRewards && Object.keys(cfg.levelRewards).length > 0) {
                    const rewards = Object.entries(cfg.levelRewards)
                        .map(([lvl, roleId]) => `Nível ${lvl} = <@&${roleId}>`)
                        .join('\n');
                    embed.addFields({ name: 'Cargos por Nível', value: rewards });
                }

                message.channel.send({ embeds: [embed] });
                break;

            default:
                message.channel.send({ embeds: [
                    new EmbedBuilder()
                        .setColor('#FFD700')
                        .setTitle('📊 Sistema de Level')
                        .setDescription([
                            '`!setlevel canal #canal` - Canal de anúncio',
                            '`!setlevel cargo <nível> @cargo` - Cargo por nível',
                            '`!setlevel ver` - Ver configurações',
                            '',
                            '**Membros:**',
                            '`!rank` - Seu nível',
                            '`!top` - Ranking'
                        ].join('\n'))
                ]});
        }
    }
};