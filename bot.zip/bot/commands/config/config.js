const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const db = require('../../utils/database');

module.exports = {
    name: 'config',
    description: 'Gerencia as configurações do bot',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('❌ Apenas administradores!');
        }

        const sub = args[0]?.toLowerCase();
        const config = db.getGuildConfig(message.guild.id);
        const embed = new EmbedBuilder().setColor('#0099ff');

        switch (sub) {
            case 'ver':
            case 'show':
                embed.setTitle('⚙️ Configurações')
                    .addFields(
                        { name: '🔧 Prefixo', value: `\`${config.prefix}\``, inline: true },
                        { name: '📝 Logs', value: config.logChannel ? `<#${config.logChannel}>` : 'Não definido', inline: true },
                        { name: '👋 Boas-vindas', value: config.welcomeChannel ? `<#${config.welcomeChannel}>` : 'Não definido', inline: true },
                        { name: '👋 Despedidas', value: config.goodbyeChannel ? `<#${config.goodbyeChannel}>` : 'Não definido', inline: true },
                        { name: '🛡️ Anti-Spam', value: config.antiSpamEnabled ? '✅ Sim' : '❌ Não', inline: true },
                        { name: '🔗 Anti-Link', value: config.antiLinkEnabled ? '✅ Sim' : '❌ Não', inline: true },
                        { name: '🚨 Anti-Raid', value: config.antiRaidEnabled ? '✅ Sim' : '❌ Não', inline: true },
                        { name: '⚠️ Warns p/ Mute', value: `${config.maxWarnsBeforeMute}`, inline: true },
                        { name: '👢 Warns p/ Kick', value: `${config.maxWarnsBeforeKick}`, inline: true },
                        { name: '🔨 Warns p/ Ban', value: `${config.maxWarnsBeforeBan}`, inline: true }
                    );
                break;

            case 'antispam':
                const as = args[1]?.toLowerCase();
                if (as === 'on' || as === 'ativar') {
                    db.setGuildConfig(message.guild.id, 'antiSpamEnabled', true);
                    embed.setDescription('✅ Anti-Spam ativado!');
                } else if (as === 'off' || as === 'desativar') {
                    db.setGuildConfig(message.guild.id, 'antiSpamEnabled', false);
                    embed.setDescription('❌ Anti-Spam desativado!');
                } else {
                    return message.reply('Use: `!config antispam on/off`');
                }
                break;

            case 'antilink':
                const al = args[1]?.toLowerCase();
                if (al === 'on' || al === 'ativar') {
                    db.setGuildConfig(message.guild.id, 'antiLinkEnabled', true);
                    embed.setDescription('✅ Anti-Link ativado!');
                } else if (al === 'off' || al === 'desativar') {
                    db.setGuildConfig(message.guild.id, 'antiLinkEnabled', false);
                    embed.setDescription('❌ Anti-Link desativado!');
                } else {
                    return message.reply('Use: `!config antilink on/off`');
                }
                break;

            case 'reset':
                db.resetGuildConfig(message.guild.id);
                embed.setDescription('🔄 Configurações resetadas!');
                break;

            default:
                embed.setTitle('📋 Ajuda de Configuração')
                    .setDescription([
                        '`!config ver` - Ver configurações',
                        '`!config antispam on/off` - Anti-Spam',
                        '`!config antilink on/off` - Anti-Link',
                        '`!config reset` - Resetar tudo',
                        '',
                        '**Comandos rápidos:**',
                        '`!setprefix <prefixo>` - Mudar prefixo',
                        '`!setlogs #canal` - Canal de logs',
                        '`!setwelcome canal #canal` - Canal de boas-vindas',
                        '`!setgoodbye canal #canal` - Canal de despedidas'
                    ].join('\n'));
        }

        message.channel.send({ embeds: [embed] });
    }
};