const { PermissionsBitField, EmbedBuilder, ChannelType } = require('discord.js');
const db = require('../../utils/database');

module.exports = {
    name: 'setwelcome',
    description: 'Configura boas-vindas',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('❌ Apenas administradores!');
        }

        const sub = args[0]?.toLowerCase();

        switch (sub) {
            case 'canal':
            case 'channel':
                const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
                if (!channel || channel.type !== ChannelType.GuildText) {
                    return message.reply('❌ Mencione um canal!\nEx: `!setwelcome canal #boas-vindas`');
                }
                db.setGuildConfig(message.guild.id, 'welcomeChannel', channel.id);
                message.channel.send(`✅ Canal de boas-vindas: ${channel}`);
                break;

            case 'mensagem':
            case 'msg':
                const msg = args.slice(1).join(' ');
                if (!msg) {
                    return message.reply(
                        '❌ Forneça a mensagem!\n' +
                        'Variáveis: `{user}`, `{user.tag}`, `{server}`, `{server.members}`\n' +
                        'Ex: `!setwelcome mensagem Bem-vindo {user} ao {server}!`'
                    );
                }
                db.setGuildConfig(message.guild.id, 'welcomeMessage', msg);
                message.channel.send(`✅ Mensagem definida: ${msg}`);
                break;

            default:
                const embed = new EmbedBuilder()
                    .setColor('#0099ff')
                    .setTitle('📋 Configuração de Boas-Vindas')
                    .setDescription([
                        '`!setwelcome canal #canal` - Define o canal',
                        '`!setwelcome mensagem <texto>` - Define a mensagem',
                        '',
                        '**Variáveis:**',
                        '`{user}` - Menciona o usuário',
                        '`{user.tag}` - Nome do usuário',
                        '`{server}` - Nome do servidor',
                        '`{server.members}` - Total de membros'
                    ].join('\n'));
                message.channel.send({ embeds: [embed] });
        }
    }
};