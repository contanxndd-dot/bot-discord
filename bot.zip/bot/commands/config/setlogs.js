const { PermissionsBitField, EmbedBuilder, ChannelType } = require('discord.js');
const db = require('../../utils/database');

module.exports = {
    name: 'setlogs',
    description: 'Define o canal de logs',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('❌ Apenas administradores!');
        }

        const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]);
        if (!channel || channel.type !== ChannelType.GuildText) {
            return message.reply('❌ Mencione um canal de texto!\nEx: `!setlogs #logs`');
        }

        db.setGuildConfig(message.guild.id, 'logChannel', channel.id);

        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('✅ Canal de Logs Definido')
            .setDescription(`Logs serão enviados em ${channel}`);

        message.channel.send({ embeds: [embed] });

        const testEmbed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('📝 Teste de Log')
            .setDescription('Canal de logs configurado!')
            .setTimestamp();

        channel.send({ embeds: [testEmbed] }).catch(() => {
            message.reply('⚠️ Não consegui enviar no canal. Verifique as permissões!');
        });
    }
};