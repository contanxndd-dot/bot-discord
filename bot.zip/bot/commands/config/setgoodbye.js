const { PermissionsBitField, EmbedBuilder, ChannelType } = require('discord.js');
const db = require('../../utils/database');

module.exports = {
    name: 'setgoodbye',
    description: 'Configura despedidas',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('❌ Apenas administradores!');
        }

        const sub = args[0]?.toLowerCase();

        switch (sub) {
            case 'canal':
            case 'channel':
                const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
                if (!channel || channel.type !== ChannelType.GuildText) {
                    return message.reply('❌ Mencione um canal!\nEx: `!setgoodbye canal #despedidas`');
                }
                db.setGuildConfig(message.guild.id, 'goodbyeChannel', channel.id);
                message.channel.send(`✅ Canal de despedidas: ${channel}`);
                break;

            case 'mensagem':
            case 'msg':
                const msg = args.slice(1).join(' ');
                if (!msg) {
                    return message.reply('❌ Forneça a mensagem!\nEx: `!setgoodbye mensagem {user} saiu do servidor!`');
                }
                db.setGuildConfig(message.guild.id, 'goodbyeMessage', msg);
                message.channel.send(`✅ Mensagem definida!`);
                break;

            default:
                const embed = new EmbedBuilder()
                    .setColor('#0099ff')
                    .setTitle('📋 Configuração de Despedidas')
                    .setDescription([
                        '`!setgoodbye canal #canal` - Define o canal',
                        '`!setgoodbye mensagem <texto>` - Define a mensagem'
                    ].join('\n'));
                message.channel.send({ embeds: [embed] });
        }
    }
};