const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const db = require('../../utils/database');

module.exports = {
    name: 'setprefix',
    description: 'Muda o prefixo do bot',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('❌ Apenas administradores!');
        }

        const newPrefix = args[0];
        if (!newPrefix || newPrefix.length > 5) {
            return message.reply('❌ Forneça um prefixo (máx. 5 caracteres)!\nEx: `!setprefix ?`');
        }

        db.setGuildConfig(message.guild.id, 'prefix', newPrefix);

        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('✅ Prefixo Alterado')
            .setDescription(`Prefixo: \`${newPrefix}\``)
            .addFields(
                { name: 'Exemplo', value: `Use \`${newPrefix}ajuda\`` }
            );

        message.channel.send({ embeds: [embed] });
    }
};