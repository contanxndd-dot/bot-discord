const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const db = require('../../utils/database');

module.exports = {
    name: 'setautomod',
    description: 'Configura o Auto-Mod',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('❌ Apenas administradores!');
        }

        const sub = args[0]?.toLowerCase();

        switch (sub) {
            case 'invite':
                const invValue = args[1]?.toLowerCase();
                if (invValue === 'on') {
                    db.setGuildConfig(message.guild.id, 'antiInvite', true);
                    message.channel.send('✅ Anti-convite ativado!');
                } else if (invValue === 'off') {
                    db.setGuildConfig(message.guild.id, 'antiInvite', false);
                    message.channel.send('❌ Anti-convite desativado!');
                } else {
                    message.reply('Use: `!setautomod invite on/off`');
                }
                break;

            case 'caps':
                const capsValue = args[1]?.toLowerCase();
                if (capsValue === 'on') {
                    db.setGuildConfig(message.guild.id, 'antiCaps', true);
                    message.channel.send('✅ Anti-caps ativado!');
                } else if (capsValue === 'off') {
                    db.setGuildConfig(message.guild.id, 'antiCaps', false);
                    message.channel.send('❌ Anti-caps desativado!');
                } else {
                    message.reply('Use: `!setautomod caps on/off`');
                }
                break;

            case 'flood':
                const floodValue = args[1]?.toLowerCase();
                if (floodValue === 'on') {
                    db.setGuildConfig(message.guild.id, 'antiFlood', true);
                    message.channel.send('✅ Anti-flood ativado!');
                } else if (floodValue === 'off') {
                    db.setGuildConfig(message.guild.id, 'antiFlood', false);
                    message.channel.send('❌ Anti-flood desativado!');
                } else {
                    message.reply('Use: `!setautomod flood on/off`');
                }
                break;

            case 'todos':
                const allValue = args[1]?.toLowerCase();
                if (allValue === 'on') {
                    db.setGuildConfig(message.guild.id, 'antiInvite', true);
                    db.setGuildConfig(message.guild.id, 'antiCaps', true);
                    db.setGuildConfig(message.guild.id, 'antiFlood', true);
                    message.channel.send('✅ Todos os sistemas de Auto-Mod ativados!');
                } else if (allValue === 'off') {
                    db.setGuildConfig(message.guild.id, 'antiInvite', false);
                    db.setGuildConfig(message.guild.id, 'antiCaps', false);
                    db.setGuildConfig(message.guild.id, 'antiFlood', false);
                    message.channel.send('❌ Todos os sistemas de Auto-Mod desativados!');
                } else {
                    message.reply('Use: `!setautomod todos on/off`');
                }
                break;

            case 'ver':
                const config = db.getGuildConfig(message.guild.id);
                const embed = new EmbedBuilder()
                    .setColor('#0099ff')
                    .setTitle('🛡️ Configuração do Auto-Mod')
                    .addFields(
                        { name: '🔗 Anti-Convite', value: config.antiInvite ? '✅ Ativado' : '❌ Desativado', inline: true },
                        { name: '🔠 Anti-Caps', value: config.antiCaps ? '✅ Ativado' : '❌ Desativado', inline: true },
                        { name: '🔄 Anti-Flood', value: config.antiFlood ? '✅ Ativado' : '❌ Desativado', inline: true }
                    );
                message.channel.send({ embeds: [embed] });
                break;

            default:
                const helpEmbed = new EmbedBuilder()
                    .setColor('#0099ff')
                    .setTitle('🛡️ Auto-Mod')
                    .setDescription([
                        '**Comandos:**',
                        '`!setautomod invite on/off` - Bloquear convites',
                        '`!setautomod caps on/off` - Bloquear excesso de maiúsculas',
                        '`!setautomod flood on/off` - Bloquear repetição de mensagens',
                        '`!setautomod todos on/off` - Ativar/desativar tudo',
                        '`!setautomod ver` - Ver configurações'
                    ].join('\n'));
                message.channel.send({ embeds: [helpEmbed] });
        }
    }
};