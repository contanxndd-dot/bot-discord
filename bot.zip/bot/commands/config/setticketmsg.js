const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const db = require('../../utils/database');

module.exports = {
    name: 'setticketmsg',
    description: 'Personaliza a mensagem do painel de tickets',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('❌ Apenas administradores!');
        }

        const sub = args[0]?.toLowerCase();

        switch (sub) {
            case 'titulo':
                const titulo = args.slice(1).join(' ');
                if (!titulo) return message.reply('❌ Use: `!setticketmsg titulo <texto>`');
                db.setGuildConfig(message.guild.id, 'ticketTitle', titulo);
                message.channel.send(`✅ Título do ticket: **${titulo}**`);
                break;

            case 'descricao':
                const descricao = args.slice(1).join(' ');
                if (!descricao) return message.reply('❌ Use: `!setticketmsg descricao <texto>`');
                db.setGuildConfig(message.guild.id, 'ticketDescription', descricao);
                message.channel.send(`✅ Descrição definida!`);
                break;

            case 'botao':
                const botao = args.slice(1).join(' ');
                if (!botao) return message.reply('❌ Use: `!setticketmsg botao <texto>`');
                db.setGuildConfig(message.guild.id, 'ticketButton', botao);
                message.channel.send(`✅ Texto do botão: **${botao}**`);
                break;

            case 'ver':
                const config = db.getGuildConfig(message.guild.id);
                const embed = new EmbedBuilder()
                    .setColor('#0099ff')
                    .setTitle('📋 Mensagem do Ticket')
                    .addFields(
                        { name: '📌 Título', value: config.ticketTitle || 'Central de Atendimento' },
                        { name: '📝 Descrição', value: (config.ticketDescription || 'Precisa de ajuda? Abra um ticket!').slice(0, 1024) },
                        { name: '🔘 Botão', value: config.ticketButton || 'Abrir Ticket' }
                    );
                message.channel.send({ embeds: [embed] });
                break;

            case 'reset':
                db.setGuildConfig(message.guild.id, 'ticketTitle', null);
                db.setGuildConfig(message.guild.id, 'ticketDescription', null);
                db.setGuildConfig(message.guild.id, 'ticketButton', null);
                message.channel.send('✅ Mensagem do ticket resetada para o padrão!');
                break;

            default:
                const helpEmbed = new EmbedBuilder()
                    .setColor('#0099ff')
                    .setTitle('🎫 Personalizar Ticket')
                    .setDescription([
                        '`!setticketmsg titulo <texto>` - Mudar título',
                        '`!setticketmsg descricao <texto>` - Mudar descrição',
                        '`!setticketmsg botao <texto>` - Mudar texto do botão',
                        '`!setticketmsg ver` - Ver mensagem atual',
                        '`!setticketmsg reset` - Voltar ao padrão',
                        '',
                        '**Exemplo:**',
                        '`!setticketmsg titulo Suporte VIP`',
                        '`!setticketmsg botao Chamar Staff`'
                    ].join('\n'));
                message.channel.send({ embeds: [helpEmbed] });
        }
    }
};