const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const db = require('../../utils/database');

module.exports = {
    name: 'lockall',
    description: 'Tranca todos os canais do servidor',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('❌ Apenas administradores!');
        }

        const motivo = args.join(' ') || 'Lockdown de emergência';
        const statusMsg = await message.channel.send('🔒 Trancando todos os canais...');

        const channels = message.guild.channels.cache.filter(c => c.isTextBased());
        let successCount = 0;
        let failCount = 0;

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('🔒 CANAL TRANCADO')
            .setDescription(`Lockdown ativado por ${message.author}`)
            .addFields({ name: '📝 Motivo', value: motivo })
            .setTimestamp();

        for (const [id, channel] of channels) {
            try {
                await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                    SendMessages: false,
                    CreatePublicThreads: false,
                    CreatePrivateThreads: false,
                    SendMessagesInThreads: false
                });
                
                if (channel.id !== message.channel.id) {
                    await channel.send({ embeds: [embed] }).catch(() => {});
                }
                
                successCount++;
            } catch (error) {
                failCount++;
            }
        }

        db.setGuildConfig(message.guild.id, 'lockdownMode', true);
        db.setGuildConfig(message.guild.id, 'emergencyMode', true);

        const finalEmbed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('🔒 LOCKDOWN ATIVADO')
            .setDescription([
                `✅ **${successCount}** canais trancados`,
                failCount > 0 ? `❌ **${failCount}** canais com erro` : '',
                '',
                `📝 **Motivo:** ${motivo}`,
                `👤 **Ativado por:** ${message.author.tag}`,
                '',
                '🔓 Use `!unlockall` para destrancar'
            ].join('\n'))
            .setTimestamp();

        await statusMsg.edit({ content: '', embeds: [finalEmbed] });

        if (client.sendLog) {
            const logEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('🔒 Lockdown Ativado')
                .addFields(
                    { name: 'Ativado por', value: message.author.tag },
                    { name: 'Motivo', value: motivo },
                    { name: 'Canais', value: `${successCount}` }
                )
                .setTimestamp();
            await client.sendLog(message.guild, logEmbed);
        }
    }
};