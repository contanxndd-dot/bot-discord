const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const protecaoManager = require('../../utils/protecaoManager');
const db = require('../../utils/database');

module.exports = {
    name: 'blacklist',
    description: 'Gerencia a blacklist',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('❌ Apenas administradores!');
        }

        const sub = args[0]?.toLowerCase();

        switch (sub) {
            case 'add':
            case 'adicionar':
                const userAdd = message.mentions.users.first() || await client.users.fetch(args[1]).catch(() => null);
                if (!userAdd) return message.reply('❌ Mencione um usuário ou forneça o ID!');

                const added = protecaoManager.addBlacklist(message.guild.id, userAdd.id);
                if (added) {
                    message.channel.send({ embeds: [
                        new EmbedBuilder().setColor('#FFA500').setTitle('⚠️ Blacklist').setDescription(`${userAdd} adicionado à blacklist`)
                    ]});
                } else {
                    message.reply('❌ Já está na blacklist!');
                }
                break;

            case 'remove':
            case 'remover':
                const userRemove = message.mentions.users.first() || await client.users.fetch(args[1]).catch(() => null);
                if (!userRemove) return message.reply('❌ Mencione um usuário ou forneça o ID!');

                protecaoManager.removeBlacklist(message.guild.id, userRemove.id);
                message.channel.send({ embeds: [
                    new EmbedBuilder().setColor('#00FF00').setTitle('✅ Blacklist').setDescription(`${userRemove} removido da blacklist`)
                ]});
                break;

            case 'list':
            case 'lista':
                const config = db.getGuildConfig(message.guild.id);
                const blacklist = config.blacklist || [];
                if (blacklist.length === 0) return message.reply('📭 Nenhum usuário na blacklist!');

                const users = [];
                for (const userId of blacklist) {
                    const user = await client.users.fetch(userId).catch(() => null);
                    if (user) users.push(`• ${user.tag}`);
                }

                message.channel.send({ embeds: [
                    new EmbedBuilder().setColor('#FFA500').setTitle('⬛ Blacklist').setDescription(users.join('\n'))
                ]});
                break;

            default:
                message.channel.send({ embeds: [
                    new EmbedBuilder().setColor('#FFA500').setTitle('⬛ Blacklist')
                        .setDescription('`!blacklist add @user` | `!blacklist remove @user` | `!blacklist list`')
                ]});
        }
    }
};