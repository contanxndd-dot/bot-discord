const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const db = require('../../utils/database');

module.exports = {
    name: 'unlockall',
    description: 'Destranca todos os canais do servidor',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('❌ Apenas administradores!');
        }

        const statusMsg = await message.channel.send('🔓 Destrancando todos os canais...');

        const channels = message.guild.channels.cache.filter(c => c.isTextBased());
        let successCount = 0;
        let failCount = 0;

        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('🔓 CANAL DESTRANCADO')
            .setDescription(`Lockdown encerrado por ${message.author}`)
            .setTimestamp();

        for (const [id, channel] of channels) {
            try {
                await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                    SendMessages: null,
                    CreatePublicThreads: null,
                    CreatePrivateThreads: null,
                    SendMessagesInThreads: null
                });
                
                if (channel.id !== message.channel.id) {
                    await channel.send({ embeds: [embed] }).catch(() => {});
                }
                
                successCount++;
            } catch (error) {
                failCount++;
            }
        }

        try {
            await message.guild.setVerificationLevel(1);
        } catch (error) {}

        db.setGuildConfig(message.guild.id, 'lockdownMode', false);
        db.setGuildConfig(message.guild.id, 'emergencyMode', false);

        const finalEmbed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('🔓 LOCKDOWN ENCERRADO')
            .setDescription([
                `✅ **${successCount}** canais destrancados`,
                failCount > 0 ? `❌ **${failCount}** canais com erro` : '',
                '',
                `👤 **Encerrado por:** ${message.author.tag}`,
                '',
                '✅ Servidor voltando ao normal'
            ].join('\n'))
            .setTimestamp();

        await statusMsg.edit({ content: '', embeds: [finalEmbed] });

        if (client.sendLog) {
            const logEmbed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('🔓 Lockdown Encerrado')
                .addFields(
                    { name: 'Encerrado por', value: message.author.tag },
                    { name: 'Canais', value: `${successCount}` }
                )
                .setTimestamp();
            await client.sendLog(message.guild, logEmbed);
        }
    }
};