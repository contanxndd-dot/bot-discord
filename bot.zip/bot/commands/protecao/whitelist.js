const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const protecaoManager = require('../../utils/protecaoManager');
const db = require('../../utils/database');

module.exports = {
    name: 'whitelist',
    description: 'Gerencia a whitelist',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('❌ Apenas administradores!');
        }

        const sub = args[0]?.toLowerCase();

        switch (sub) {
            case 'add':
            case 'adicionar':
                const userAdd = message.mentions.users.first() || await client.users.fetch(args[1]).catch(() => null);
                if (!userAdd) return message.reply('❌ Mencione um usuário ou forneça o ID!');

                const added = protecaoManager.addWhitelist(message.guild.id, userAdd.id);
                if (added) {
                    message.channel.send({ embeds: [
                        new EmbedBuilder().setColor('#00FF00').setTitle('✅ Whitelist').setDescription(`${userAdd} adicionado à whitelist`)
                    ]});
                } else {
                    message.reply('❌ Já está na whitelist!');
                }
                break;

            case 'remove':
            case 'remover':
                const userRemove = message.mentions.users.first() || await client.users.fetch(args[1]).catch(() => null);
                if (!userRemove) return message.reply('❌ Mencione um usuário ou forneça o ID!');

                protecaoManager.removeWhitelist(message.guild.id, userRemove.id);
                message.channel.send({ embeds: [
                    new EmbedBuilder().setColor('#FF0000').setTitle('❌ Whitelist').setDescription(`${userRemove} removido da whitelist`)
                ]});
                break;

            case 'list':
            case 'lista':
                const config = db.getGuildConfig(message.guild.id);
                const whitelist = config.whitelist || [];
                if (whitelist.length === 0) return message.reply('📭 Nenhum usuário na whitelist!');

                const users = [];
                for (const userId of whitelist) {
                    const user = await client.users.fetch(userId).catch(() => null);
                    if (user) users.push(`• ${user.tag}`);
                }

                message.channel.send({ embeds: [
                    new EmbedBuilder().setColor('#0099ff').setTitle('⬜ Whitelist').setDescription(users.join('\n'))
                ]});
                break;

            default:
                message.channel.send({ embeds: [
                    new EmbedBuilder().setColor('#0099ff').setTitle('⬜ Whitelist')
                        .setDescription('`!whitelist add @user` | `!whitelist remove @user` | `!whitelist list`')
                ]});
        }
    }
};