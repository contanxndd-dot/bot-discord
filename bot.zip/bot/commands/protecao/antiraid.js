const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const db = require('../../utils/database');

module.exports = {
    name: 'antiraid',
    description: 'Sistema anti-raid do servidor',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('❌ Apenas administradores!');
        }

        const sub = args[0]?.toLowerCase();

        switch (sub) {
            case 'on':
            case 'ativar':
                db.setGuildConfig(message.guild.id, 'antiRaidEnabled', true);
                message.channel.send({ embeds: [
                    new EmbedBuilder()
                        .setColor('#00FF00')
                        .setTitle('🛡️ Anti-Raid Ativado')
                        .setDescription('Proteção contra raids ativada!\nUse `!antiraid status` para ver.')
                ]});
                break;

            case 'off':
            case 'desativar':
                db.setGuildConfig(message.guild.id, 'antiRaidEnabled', false);
                message.channel.send({ embeds: [
                    new EmbedBuilder()
                        .setColor('#FF0000')
                        .setTitle('🛡️ Anti-Raid Desativado')
                        .setDescription('⚠️ Seu servidor está vulnerável!')
                ]});
                break;

            case 'status':
                const config = db.getGuildConfig(message.guild.id);
                const embed = new EmbedBuilder()
                    .setColor('#0099ff')
                    .setTitle('🛡️ Status Anti-Raid')
                    .addFields(
                        { name: 'Sistema', value: config.antiRaidEnabled ? '✅ Ativado' : '❌ Desativado', inline: true },
                        { name: 'Modo Emergência', value: config.emergencyMode ? '🚨 Sim' : '✅ Não', inline: true },
                        { name: 'Whitelist', value: `${(config.whitelist || []).length} usuários`, inline: true },
                        { name: 'Blacklist', value: `${(config.blacklist || []).length} usuários`, inline: true }
                    );
                message.channel.send({ embeds: [embed] });
                break;

            default:
                message.channel.send({ embeds: [
                    new EmbedBuilder()
                        .setColor('#0099ff')
                        .setTitle('🛡️ Anti-Raid')
                        .setDescription([
                            '`!antiraid on` - Ativar',
                            '`!antiraid off` - Desativar',
                            '`!antiraid status` - Ver status'
                        ].join('\n'))
                ]});
        }
    }
};