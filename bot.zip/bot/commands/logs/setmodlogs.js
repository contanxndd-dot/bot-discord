const { PermissionsBitField, EmbedBuilder, ChannelType } = require('discord.js');
const db = require('../../utils/database');

module.exports = {
    name: 'setmodlogs',
    description: 'Configura canais de logs específicos',
    async execute(message, args, client) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('❌ Apenas administradores!');
        }

        const sub = args[0]?.toLowerCase();
        const embed = new EmbedBuilder().setColor('#0099ff');

        switch (sub) {
            case 'todos':
            case 'all':
                const mainChannel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
                if (!mainChannel || mainChannel.type !== ChannelType.GuildText) {
                    return message.reply('❌ Mencione um canal de texto!');
                }
                db.setGuildConfig(message.guild.id, 'logChannel', mainChannel.id);
                message.channel.send(`✅ Logs gerais: ${mainChannel}`);
                break;

            case 'moderacao':
            case 'mod':
                const modChannel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
                if (!modChannel || modChannel.type !== ChannelType.GuildText) {
                    return message.reply('❌ Mencione um canal!');
                }
                db.setGuildConfig(message.guild.id, 'modLogChannel', modChannel.id);
                message.channel.send(`✅ Logs de moderação: ${modChannel}`);
                break;

            case 'mensagens':
            case 'messages':
                const msgChannel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
                if (!msgChannel || msgChannel.type !== ChannelType.GuildText) {
                    return message.reply('❌ Mencione um canal!');
                }
                db.setGuildConfig(message.guild.id, 'messageLogChannel', msgChannel.id);
                message.channel.send(`✅ Logs de mensagens: ${msgChannel}`);
                break;

            case 'voice':
            case 'voz':
                const voiceChannel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
                if (!voiceChannel || voiceChannel.type !== ChannelType.GuildText) {
                    return message.reply('❌ Mencione um canal!');
                }
                db.setGuildConfig(message.guild.id, 'voiceLogChannel', voiceChannel.id);
                message.channel.send(`✅ Logs de voz: ${voiceChannel}`);
                break;

            case 'membros':
            case 'members':
                const memberChannel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
                if (!memberChannel || memberChannel.type !== ChannelType.GuildText) {
                    return message.reply('❌ Mencione um canal!');
                }
                db.setGuildConfig(message.guild.id, 'memberLogChannel', memberChannel.id);
                message.channel.send(`✅ Logs de membros: ${memberChannel}`);
                break;

            case 'cargos':
            case 'roles':
                const roleChannel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
                if (!roleChannel || roleChannel.type !== ChannelType.GuildText) {
                    return message.reply('❌ Mencione um canal!');
                }
                db.setGuildConfig(message.guild.id, 'roleLogChannel', roleChannel.id);
                message.channel.send(`✅ Logs de cargos: ${roleChannel}`);
                break;

            case 'ver':
            case 'show':
                const config = db.getGuildConfig(message.guild.id);
                embed.setTitle('📝 Configuração de Logs')
                    .addFields(
                        { name: '📋 Gerais', value: config.logChannel ? `<#${config.logChannel}>` : '❌ Não configurado', inline: true },
                        { name: '🛡️ Moderação', value: config.modLogChannel ? `<#${config.modLogChannel}>` : '❌ Não configurado', inline: true },
                        { name: '💬 Mensagens', value: config.messageLogChannel ? `<#${config.messageLogChannel}>` : '❌ Não configurado', inline: true },
                        { name: '🔊 Voz', value: config.voiceLogChannel ? `<#${config.voiceLogChannel}>` : '❌ Não configurado', inline: true },
                        { name: '👥 Membros', value: config.memberLogChannel ? `<#${config.memberLogChannel}>` : '❌ Não configurado', inline: true },
                        { name: '🎭 Cargos', value: config.roleLogChannel ? `<#${config.roleLogChannel}>` : '❌ Não configurado', inline: true }
                    );
                message.channel.send({ embeds: [embed] });
                break;

            case 'desativar':
            case 'off':
                const type = args[1]?.toLowerCase();
                const logTypes = {
                    'todos': 'logChannel',
                    'moderacao': 'modLogChannel',
                    'mensagens': 'messageLogChannel',
                    'voz': 'voiceLogChannel',
                    'membros': 'memberLogChannel',
                    'cargos': 'roleLogChannel'
                };
                
                if (logTypes[type]) {
                    db.setGuildConfig(message.guild.id, logTypes[type], null);
                    message.channel.send(`✅ Logs de ${type} desativados!`);
                } else {
                    message.reply('❌ Tipo inválido! Use: todos, moderacao, mensagens, voz, membros, cargos');
                }
                break;

            default:
                embed.setTitle('📝 Configuração de Logs')
                    .setDescription([
                        '**Comandos:**',
                        '`!setmodlogs todos #canal` - Logs gerais',
                        '`!setmodlogs moderacao #canal` - Bans, kicks, mutes, warns',
                        '`!setmodlogs mensagens #canal` - Mensagens editadas/deletadas',
                        '`!setmodlogs voz #canal` - Entrada/saída de voz',
                        '`!setmodlogs membros #canal` - Entrada/saída do servidor',
                        '`!setmodlogs cargos #canal` - Alterações de cargos',
                        '',
                        '`!setmodlogs ver` - Ver configuração',
                        '`!setmodlogs desativar <tipo>` - Desativar logs'
                    ].join('\n'));
                message.channel.send({ embeds: [embed] });
        }
    }
};